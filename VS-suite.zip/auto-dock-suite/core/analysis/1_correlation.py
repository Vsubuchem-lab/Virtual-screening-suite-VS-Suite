
"""Correlation analysis across Boltz-2 / AutoDock Vina / GNINA."""

import json
import re
import sys
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


COLUMN_ALIASES = {
    "ligand": "ligand",
    "title": "ligand",
    "name": "ligand",
    "boltz ic50 um": "boltz_ic50_uM",
    "boltz ic50 (um)": "boltz_ic50_uM",
    "boltz ic50": "boltz_ic50_uM",
    "boltz_ic50_um": "boltz_ic50_uM",
    "boltz p(binder)": "boltz_p_binder",
    "boltz p binder": "boltz_p_binder",
    "boltz_p_binder": "boltz_p_binder",
    "boltz iptm": "boltz_iptm",
    "boltz_iptm": "boltz_iptm",
    "vina dg (kcal/mol)": "vina_dG",
    "vina_dg": "vina_dG",
    "gnina dg (kcal/mol)": "gnina_dG",
    "gnina dg": "gnina_dG",
    "gnina_dg": "gnina_dG",
    "gnina cnn pose": "gnina_cnn_pose",
    "gnina_cnn_pose": "gnina_cnn_pose",
    "gnina cnn pk": "gnina_cnn_pK",
    "gnina_cnn_pk": "gnina_cnn_pK",
}


def normalize_header(header):
    """Normalize Unicode symbols and spacing in CSV column names."""
    text = unicodedata.normalize("NFKC", str(header))
    text = text.replace("μ", "u").replace("µ", "u")
    text = text.replace("Δ", "d")
    return re.sub(r"[_\s]+", " ", text.strip().lower())


def normalize_csv_columns(df):
    """Map CSV headers to the internal column names."""
    aliases = {
        normalize_header(key): value
        for key, value in COLUMN_ALIASES.items()
    }

    rename = {}
    for col in df.columns:
        key = normalize_header(col)
        if key in aliases and col != aliases[key]:
            rename[col] = aliases[key]

    df = df.rename(columns=rename)

    duplicated = df.columns[df.columns.duplicated()].tolist()
    if duplicated:
        raise ValueError(
            f"Duplicate columns after normalization: {duplicated}"
        )

    return df


def load_from_master_json(master_json):
    """Build a DataFrame from results_master.json."""
    master = json.loads(
        Path(master_json).read_text(encoding="utf-8")
    )

    rows = []

    for ligand in master.get("per_ligand", []):
        results = ligand.get("results") or {}
        boltz = results.get("boltz") or {}
        vina = results.get("vina") or {}
        gnina = results.get("gnina") or {}

        affinity = boltz.get("affinity") or {}
        confidence = boltz.get("confidence") or {}

        rows.append({
            "ligand": ligand.get("title"),
            "smiles": ligand.get("smiles"),
            "boltz_ic50_uM": affinity.get("ic50_uM"),
            "boltz_p_binder": affinity.get(
                "affinity_probability_binary"
            ),
            "boltz_iptm": confidence.get("iptm"),
            "vina_dG": vina.get("best_affinity_kcal_mol"),
            "gnina_dG": gnina.get("best_affinity_kcal_mol"),
            "gnina_cnn_pose": gnina.get("best_cnn_pose_score"),
            "gnina_cnn_pK": gnina.get("best_cnn_affinity_pK"),
        })

    return pd.DataFrame(rows)


def numeric_column(df, column):
    """Convert a column to numeric, or return NaNs if unavailable."""
    if column not in df.columns:
        return pd.Series(np.nan, index=df.index, dtype=float)

    return pd.to_numeric(df[column], errors="coerce")


def prepare_correlation_data(df):
    """Prepare metrics with consistent direction where appropriate.

    pIC50 = -log10(IC50 in molar units).
    Higher values indicate stronger predicted binding for the
    transformed affinity metrics.
    """
    ic50_um = numeric_column(df, "boltz_ic50_uM")
    ic50_um = ic50_um.where(ic50_um > 0)

    # Convert micromolar to molar before calculating conventional pIC50.
    pic50 = -np.log10(ic50_um * 1e-6)

    work = pd.DataFrame({
        "Boltz P(binder)": numeric_column(
            df, "boltz_p_binder"
        ),
        "Boltz pIC50": pic50,
        "Vina (-dG)": -numeric_column(df, "vina_dG"),
        "GNINA (-dG)": -numeric_column(df, "gnina_dG"),
        "GNINA CNN pK": numeric_column(df, "gnina_cnn_pK"),
        "GNINA CNN pose": numeric_column(df, "gnina_cnn_pose"),
    }, index=df.index)

    # Omit metrics absent from the input file.
    work = work.dropna(axis=1, how="all")

    if work.shape[1] < 2:
        raise ValueError(
            "At least two usable scoring metrics are required.\n"
            f"Available columns: {df.columns.tolist()}"
        )

    return work


def correlation_matrix(df, method="pearson"):
    """Calculate pairwise correlations and p-values.

    Each pair uses all rows with valid values for those two metrics.
    """
    if method not in ("pearson", "spearman"):
        raise ValueError("method must be pearson or spearman")

    work = prepare_correlation_data(df)
    columns = list(work.columns)

    corr = pd.DataFrame(
        np.nan, index=columns, columns=columns
    )
    pvals = pd.DataFrame(
        np.nan, index=columns, columns=columns
    )

    for col_a in columns:
        for col_b in columns:
            pair = work[[col_a, col_b]].dropna()

            if col_a == col_b:
                if len(pair) >= 2 and pair[col_a].nunique() > 1:
                    corr.loc[col_a, col_b] = 1.0
                    pvals.loc[col_a, col_b] = 0.0
                continue

            if len(pair) < 3:
                continue

            a = pair[col_a].to_numpy(dtype=float)
            b = pair[col_b].to_numpy(dtype=float)

            # Correlation is undefined for constant values.
            if np.ptp(a) == 0 or np.ptp(b) == 0:
                continue

            if method == "pearson":
                result = stats.pearsonr(a, b)
            else:
                result = stats.spearmanr(a, b)

            corr.loc[col_a, col_b] = result.statistic
            pvals.loc[col_a, col_b] = result.pvalue

    return corr, pvals, work


def summarize_correlations(df):
    """Summarize selected cross-tool correlations."""
    pearson, pearson_p, work = correlation_matrix(
        df, "pearson"
    )
    spearman, spearman_p, _ = correlation_matrix(
        df, "spearman"
    )

    pairs = [
        ("Boltz P(binder)", "Vina (-dG)"),
        ("Boltz P(binder)", "GNINA CNN pK"),
        ("Vina (-dG)", "GNINA (-dG)"),
        ("Vina (-dG)", "GNINA CNN pK"),
        ("GNINA (-dG)", "GNINA CNN pK"),
    ]

    summary = {
        "n_ligands": int(len(df)),
        "correlations": {},
    }

    for a, b in pairs:
        if a not in pearson.index or b not in pearson.columns:
            continue

        n = len(work[[a, b]].dropna())

        summary["correlations"][f"{a} vs {b}"] = {
            "n": int(n),
            "pearson_r": (
                None if pd.isna(pearson.loc[a, b])
                else round(float(pearson.loc[a, b]), 4)
            ),
            "pearson_p": (
                None if pd.isna(pearson_p.loc[a, b])
                else float(pearson_p.loc[a, b])
            ),
            "spearman_rho": (
                None if pd.isna(spearman.loc[a, b])
                else round(float(spearman.loc[a, b]), 4)
            ),
            "spearman_p": (
                None if pd.isna(spearman_p.loc[a, b])
                else float(spearman_p.loc[a, b])
            ),
        }

    return summary


def plot_correlation_heatmap(corr, title, output_path):
    """Save a publication-quality heatmap as PNG and PDF."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(8, 6.5))

    sns.heatmap(
        corr,
        annot=True,
        fmt=".2f",
        cmap="RdBu_r",
        center=0,
        vmin=-1,
        vmax=1,
        square=True,
        cbar_kws={"label": "Correlation coefficient"},
        linewidths=0.5,
        linecolor="white",
        ax=ax,
    )

    ax.set_title(title, fontsize=12, pad=12)
    plt.xticks(rotation=35, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()

    output_path = Path(output_path)
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    fig.savefig(output_path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)

    return str(output_path)


def plot_pairwise_scatter(work, output_path):
    """Save pairwise scatter plots as PNG and PDF."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    diag_kind = "kde" if len(work) >= 5 else "hist"

    grid = sns.pairplot(
        work,
        diag_kind=diag_kind,
        plot_kws={"alpha": 0.6, "s": 25},
    )

    grid.fig.suptitle(
        "VS-Suite cross-tool score relationships",
        y=1.02,
        fontsize=13,
    )

    output_path = Path(output_path)
    grid.fig.savefig(output_path, dpi=300, bbox_inches="tight")
    grid.fig.savefig(output_path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(grid.fig)

    return str(output_path)


def run_correlation_analysis(input_csv_or_json, output_dir):
    """Run analysis from a VS-Suite CSV or master JSON."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    source = Path(input_csv_or_json)

    if source.suffix.lower() == ".json":
        df = load_from_master_json(source)
    else:
        df = normalize_csv_columns(pd.read_csv(source))

    work = prepare_correlation_data(df)

    pearson_corr, pearson_p, _ = correlation_matrix(
        df, "pearson"
    )
    spearman_corr, spearman_p, _ = correlation_matrix(
        df, "spearman"
    )

    pearson_corr.to_csv(output_dir / "pearson_corr.csv")
    pearson_p.to_csv(output_dir / "pearson_pvals.csv")
    spearman_corr.to_csv(output_dir / "spearman_corr.csv")
    spearman_p.to_csv(output_dir / "spearman_pvals.csv")

    summary = summarize_correlations(df)

    (output_dir / "correlation_summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    plot_correlation_heatmap(
        pearson_corr,
        f"VS-Suite Pearson correlation (n={len(work)})",
        output_dir / "pearson_heatmap.png",
    )

    plot_correlation_heatmap(
        spearman_corr,
        f"VS-Suite Spearman correlation (n={len(work)})",
        output_dir / "spearman_heatmap.png",
    )

    complete = work.dropna()

    if len(complete) >= 2:
        plot_pairwise_scatter(
            complete,
            output_dir / "pairwise_scatter.png",
        )
    else:
        print(
            "Skipping pair plot: fewer than two rows have complete "
            "values across all available metrics."
        )

    return {
        "n_ligands": int(len(df)),
        "n_complete_rows_for_pairplot": int(len(complete)),
        "metrics": list(work.columns),
        "output_dir": str(output_dir),
        "pearson_corr_csv": str(
            output_dir / "pearson_corr.csv"
        ),
        "summary": summary,
    }


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(
            "Usage: python -m core.analysis.correlation "
            "<input_csv_or_json> <output_dir>"
        )
        sys.exit(1)

    info = run_correlation_analysis(sys.argv[1], sys.argv[2])
    print(json.dumps(info, indent=2, default=str, allow_nan=False))

