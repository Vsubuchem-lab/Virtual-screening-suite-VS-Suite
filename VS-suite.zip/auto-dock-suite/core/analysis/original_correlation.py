"""Correlation analysis across Boltz / Vina / GNINA.

Reads a VS-Suite results CSV (or master JSON), computes pairwise
Pearson + Spearman correlations, generates publication-quality plots.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats


def load_from_master_json(master_json):
    """Build a DataFrame from results_master.json."""
    m = json.loads(Path(master_json).read_text())
    rows = []
    for L in m.get("per_ligand", []):
        r = L.get("results") or {}
        b = r.get("boltz") or {}
        v = r.get("vina") or {}
        g = r.get("gnina") or {}
        aff = b.get("affinity") or {}
        conf = b.get("confidence") or {}
        rows.append({
            "ligand": L.get("title"),
            "smiles": L.get("smiles"),
            "boltz_ic50_uM": aff.get("ic50_uM"),
            "boltz_p_binder": aff.get("affinity_probability_binary"),
            "boltz_iptm": conf.get("iptm"),
            "vina_dG": v.get("best_affinity_kcal_mol"),
            "gnina_dG": g.get("best_affinity_kcal_mol"),
            "gnina_cnn_pose": g.get("best_cnn_pose_score"),
            "gnina_cnn_pK": g.get("best_cnn_affinity_pK"),
        })
    return pd.DataFrame(rows)


def correlation_matrix(df, method: str = "pearson"):
    """Compute pairwise correlations between scoring metrics.

    For binding strength, we use these aligned directions (higher = stronger binder):
      - boltz_p_binder (already higher = better)
      - -vina_dG (negate, so higher = stronger)
      - -gnina_dG (negate, so higher = stronger)
      - gnina_cnn_pK (already higher = better)
    """
    work = pd.DataFrame({
        "Boltz P(binder)": df["boltz_p_binder"],
        "Boltz -log10(IC50)": -np.log10(df["boltz_ic50_uM"]),
        "Vina (-dG)": -df["vina_dG"],
        "GNINA (-dG)": -df["gnina_dG"],
        "GNINA CNN pK": df["gnina_cnn_pK"],
        "GNINA CNN pose": df["gnina_cnn_pose"],
    }).dropna()

    if method == "pearson":
        corr = work.corr(method="pearson")
    elif method == "spearman":
        corr = work.corr(method="spearman")
    else:
        raise ValueError("method must be pearson or spearman")

    # Compute p-values for each pair
    cols = list(work.columns)
    n = len(cols)
    pvals = pd.DataFrame(np.ones((n, n)), index=cols, columns=cols)
    for i in range(n):
        for j in range(n):
            if i == j: continue
            a, b = work[cols[i]].values, work[cols[j]].values
            if method == "pearson":
                r, p = stats.pearsonr(a, b)
            else:
                r, p = stats.spearmanr(a, b)
            pvals.iloc[i, j] = p
    return corr, pvals, work


def summarize_correlations(df) -> dict:
    """Return key cross-tool correlations as a flat summary dict."""
    pearson_corr, pearson_p, _ = correlation_matrix(df, "pearson")
    spearman_corr, spearman_p, _ = correlation_matrix(df, "spearman")

    pairs = [
        ("Boltz P(binder)", "Vina (-dG)"),
        ("Boltz P(binder)", "GNINA CNN pK"),
        ("Vina (-dG)",       "GNINA (-dG)"),
        ("Vina (-dG)",       "GNINA CNN pK"),
        ("GNINA (-dG)",      "GNINA CNN pK"),
    ]
    out = {"n_ligands": len(df)}
    for a, b in pairs:
        out[f"pearson_{a}_vs_{b}"] = {
            "r": round(pearson_corr.loc[a, b], 4),
            "p": float(pearson_p.loc[a, b]),
        }
        out[f"spearman_{a}_vs_{b}"] = {
            "rho": round(spearman_corr.loc[a, b], 4),
            "p": float(spearman_p.loc[a, b]),
        }
    return out


def plot_correlation_heatmap(corr, title, output_path):
    """Publication-quality heatmap."""
    import matplotlib.pyplot as plt
    import seaborn as sns
    fig, ax = plt.subplots(figsize=(8, 6.5))
    sns.heatmap(
        corr, annot=True, fmt=".2f", cmap="RdBu_r",
        center=0, vmin=-1, vmax=1, square=True,
        cbar_kws={"label": "Correlation"},
        linewidths=0.5, linecolor="white",
        ax=ax,
    )
    ax.set_title(title, fontsize=12, pad=12)
    plt.xticks(rotation=35, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    fig.savefig(str(output_path).replace(".png", ".pdf"), bbox_inches="tight")
    plt.close(fig)
    return output_path


def plot_pairwise_scatter(work, output_path):
    """Pair plot of all metrics."""
    import matplotlib.pyplot as plt
    import seaborn as sns
    g = sns.pairplot(work, diag_kind="kde", plot_kws={"alpha": 0.6, "s": 25})
    g.fig.suptitle("VS-Suite cross-tool score relationships", y=1.02, fontsize=13)
    g.fig.savefig(output_path, dpi=300, bbox_inches="tight")
    g.fig.savefig(str(output_path).replace(".png", ".pdf"), bbox_inches="tight")
    plt.close(g.fig)
    return output_path


def run_correlation_analysis(input_csv_or_json, output_dir):
    """Run full correlation analysis. Accepts a CSV or results_master.json."""
    output_dir = Path(output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    src = Path(input_csv_or_json)
    if src.suffix.lower() == ".json":
        df = load_from_master_json(src)
    else:
        df = pd.read_csv(src)
        # Normalize column names to internal scheme
        rename = {}
        cols_lower = {c.lower(): c for c in df.columns}
        mapping = {
            "ligand": "ligand", "title": "ligand", "name": "ligand",
            "boltz ic50 (um)": "boltz_ic50_uM",
            "boltz_ic50_um": "boltz_ic50_uM",
            "boltz p(binder)": "boltz_p_binder",
            "boltz_p_binder": "boltz_p_binder",
            "boltz iptm": "boltz_iptm",
            "vina dg (kcal/mol)": "vina_dG",
            "vina_dg": "vina_dG",
            "vina dg": "vina_dG",
            "gnina dg (kcal/mol)": "gnina_dG",
            "gnina_dg": "gnina_dG",
            "gnina cnn pose": "gnina_cnn_pose",
            "gnina_cnn_pose": "gnina_cnn_pose",
            "gnina cnn pk": "gnina_cnn_pK",
            "gnina_cnn_pk": "gnina_cnn_pK",
        }
        for k_lower, std in mapping.items():
            if k_lower in cols_lower and cols_lower[k_lower] != std:
                rename[cols_lower[k_lower]] = std
        df = df.rename(columns=rename)

    pearson_corr, pearson_p, work = correlation_matrix(df, "pearson")
    spearman_corr, spearman_p, _  = correlation_matrix(df, "spearman")

    # Save matrices
    pearson_corr.to_csv(output_dir / "pearson_corr.csv")
    pearson_p.to_csv(output_dir / "pearson_pvals.csv")
    spearman_corr.to_csv(output_dir / "spearman_corr.csv")
    spearman_p.to_csv(output_dir / "spearman_pvals.csv")

    summary = summarize_correlations(df)
    (output_dir / "correlation_summary.json").write_text(
        json.dumps(summary, indent=2)
    )

    # Plots
    plot_correlation_heatmap(pearson_corr,
        f"VS-Suite Pearson correlation (n={len(work)})",
        output_dir / "pearson_heatmap.png")
    plot_correlation_heatmap(spearman_corr,
        f"VS-Suite Spearman correlation (n={len(work)})",
        output_dir / "spearman_heatmap.png")
    plot_pairwise_scatter(work, output_dir / "pairwise_scatter.png")

    return {
        "n_ligands": len(work),
        "output_dir": str(output_dir),
        "pearson_corr_csv": str(output_dir / "pearson_corr.csv"),
        "summary": summary,
    }


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Usage: python -m core.analysis.correlation <input_csv_or_json> <output_dir>")
        sys.exit(1)
    info = run_correlation_analysis(sys.argv[1], sys.argv[2])
    print(json.dumps(info, indent=2, default=str))
