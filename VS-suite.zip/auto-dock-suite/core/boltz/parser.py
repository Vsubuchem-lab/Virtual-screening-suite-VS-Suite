"""Parse Boltz-2 prediction outputs.

Splits the predicted complex into:
  - protein-only PDB (for Vina/GNINA receptor prep)
  - ligand-only SDF + PDB (for docking pose ref + box)
  - binding box (for Vina/GNINA search box)

Reads affinity + confidence JSON.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import json
from rdkit import Chem


def split_complex_pdb(complex_pdb,
                      out_protein_pdb,
                      out_ligand_pdb,
                      ligand_chain_id: str = None) -> dict:
    """Split a Boltz complex PDB into protein-only and ligand-only PDBs.

    Boltz writes ligands as HETATM with a unique chain ID. Convention in
    our YAMLs: ligand chain is the last letter (e.g., B for monomer, C for dimer).

    Args:
        complex_pdb: input PDB from Boltz
        out_protein_pdb: target path for protein-only PDB
        out_ligand_pdb: target path for ligand-only PDB
        ligand_chain_id: if known, restrict ligand extraction to this chain

    Returns:
        dict {n_protein_atoms, n_ligand_atoms, ligand_chain, ligand_resname}
    """
    complex_pdb = Path(complex_pdb)
    out_protein_pdb = Path(out_protein_pdb)
    out_ligand_pdb = Path(out_ligand_pdb)
    out_protein_pdb.parent.mkdir(parents=True, exist_ok=True)
    out_ligand_pdb.parent.mkdir(parents=True, exist_ok=True)

    if not complex_pdb.exists():
        raise FileNotFoundError(f"Complex PDB not found: {complex_pdb}")

    protein_lines = []
    ligand_lines = []
    other_lines = []
    detected_lig_chain = None
    detected_lig_resname = None

    for ln in complex_pdb.read_text().splitlines():
        if ln.startswith("ATOM"):
            protein_lines.append(ln)
        elif ln.startswith("HETATM"):
            this_chain = ln[21:22].strip()
            this_res = ln[17:20].strip()
            # Skip water if any
            if this_res in ("HOH", "WAT", "TIP", "TIP3"):
                continue
            if ligand_chain_id and this_chain != ligand_chain_id:
                # Could be a non-target HETATM (cofactor); keep with protein
                protein_lines.append(ln)
                continue
            ligand_lines.append(ln)
            if detected_lig_chain is None:
                detected_lig_chain = this_chain
                detected_lig_resname = this_res
        elif ln.startswith(("TER", "END")):
            other_lines.append(ln)
        elif ln.startswith(("HEADER", "TITLE", "REMARK", "CRYST1")):
            # Keep headers in both files
            protein_lines.insert(0, ln) if not protein_lines else other_lines.append(ln)

    # Write protein PDB
    out_protein_pdb.write_text("\n".join(protein_lines + ["END"]) + "\n")

    # Write ligand PDB
    out_ligand_pdb.write_text("\n".join(ligand_lines + ["END"]) + "\n")

    return {
        "complex_pdb": str(complex_pdb),
        "protein_pdb": str(out_protein_pdb),
        "ligand_pdb": str(out_ligand_pdb),
        "n_protein_atoms": len(protein_lines),
        "n_ligand_atoms": len(ligand_lines),
        "ligand_chain": detected_lig_chain,
        "ligand_resname": detected_lig_resname,
    }


def ligand_pdb_to_sdf(ligand_pdb, output_sdf, conda_env: str = "autodock-prep") -> dict:
    """Convert a ligand-only PDB to SDF using OpenBabel.

    OpenBabel preserves bond perception better than RDKit for HETATM-only PDBs.
    """
    from core.utils.conda_runner import run_in_conda_env
    ligand_pdb = Path(ligand_pdb)
    output_sdf = Path(output_sdf)
    output_sdf.parent.mkdir(parents=True, exist_ok=True)

    cmd = ["obabel", str(ligand_pdb), "-O", str(output_sdf)]
    r = run_in_conda_env(conda_env, cmd, timeout=120)
    if r.returncode != 0 or not output_sdf.exists():
        raise RuntimeError(
            f"OpenBabel PDB->SDF failed: {r.stderr[-500:]}"
        )
    return {
        "ligand_pdb": str(ligand_pdb),
        "ligand_sdf": str(output_sdf),
        "size_bytes": output_sdf.stat().st_size,
    }


def compute_box_from_ligand(ligand_pdb, padding: float = 5.0,
                            min_size: float = 18.0,
                            max_size: float = 30.0) -> dict:
    """Compute Vina/GNINA box from ligand atom coordinates."""
    coords = []
    for ln in Path(ligand_pdb).read_text().splitlines():
        if ln.startswith(("ATOM", "HETATM")) and len(ln) >= 54:
            try:
                x = float(ln[30:38])
                y = float(ln[38:46])
                z = float(ln[46:54])
                coords.append((x, y, z))
            except ValueError:
                continue

    if not coords:
        raise RuntimeError(f"No atoms parsed from {ligand_pdb}")

    xs, ys, zs = zip(*coords)
    cx = (min(xs) + max(xs)) / 2.0
    cy = (min(ys) + max(ys)) / 2.0
    cz = (min(zs) + max(zs)) / 2.0
    sx = (max(xs) - min(xs)) + 2 * padding
    sy = (max(ys) - min(ys)) + 2 * padding
    sz = (max(zs) - min(zs)) + 2 * padding
    sx = max(min_size, min(sx, max_size))
    sy = max(min_size, min(sy, max_size))
    sz = max(min_size, min(sz, max_size))

    return {
        "center": [round(cx, 3), round(cy, 3), round(cz, 3)],
        "size": [round(sx, 1), round(sy, 1), round(sz, 1)],
        "n_atoms_used": len(coords),
        "padding": padding,
    }


def read_confidence(json_path) -> dict:
    """Parse a Boltz confidence_*.json."""
    data = json.loads(Path(json_path).read_text())
    return {
        "confidence_score": data.get("confidence_score"),
        "ptm": data.get("ptm"),
        "iptm": data.get("iptm"),
        "ligand_iptm": data.get("ligand_iptm"),
        "protein_iptm": data.get("protein_iptm"),
        "complex_plddt": data.get("complex_plddt"),
        "complex_iplddt": data.get("complex_iplddt"),
        "raw": data,
    }


def read_affinity(json_path) -> dict:
    """Parse a Boltz affinity_*.json.

    Note: affinity_pred_value is log10(IC50_uM).
    Lower = stronger binder. Convert to pIC50 (kcal/mol) via (6 - y) * 1.364.
    """
    data = json.loads(Path(json_path).read_text())
    pred = data.get("affinity_pred_value")
    pic50_kcalmol = (6.0 - pred) * 1.364 if pred is not None else None
    ic50_uM = (10 ** pred) if pred is not None else None

    return {
        "affinity_pred_value_log10_IC50uM": pred,
        "affinity_probability_binary": data.get("affinity_probability_binary"),
        "ic50_uM": round(ic50_uM, 4) if ic50_uM else None,
        "pic50_kcalmol_proxy": round(pic50_kcalmol, 3) if pic50_kcalmol else None,
        "raw": data,
    }


def parse_boltz_output(predictions_dir,
                       output_dir,
                       ligand_chain_id: str = None,
                       model_index: int = 0,
                       padding: float = 5.0) -> dict:
    """Full parse of one Boltz prediction folder.

    Args:
        predictions_dir: path to Boltz predictions/<job_name>/ folder
        output_dir: where to write split protein PDB, ligand PDB, ligand SDF, box JSON
        ligand_chain_id: chain ID of ligand (e.g., "B" for monomer, "C" for dimer).
                         If None, auto-detect from first HETATM.
        model_index: which model to use (Boltz outputs 0..N-1 by confidence rank)
        padding: box padding in Angstroms

    Returns:
        dict with all paths + scores
    """
    pred_dir = Path(predictions_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not pred_dir.exists():
        raise FileNotFoundError(f"Predictions dir not found: {pred_dir}")

    # Find the model PDB
    job_name = pred_dir.name
    pdb_candidates = list(pred_dir.glob(f"{job_name}_model_{model_index}.pdb"))
    if not pdb_candidates:
        # Try cif fallback
        cif_candidates = list(pred_dir.glob(f"{job_name}_model_{model_index}.cif"))
        if cif_candidates:
            raise RuntimeError(
                f"Found CIF but not PDB. Re-run Boltz with --output_format pdb "
                f"or add CIF parser. CIF: {cif_candidates[0]}"
            )
        raise FileNotFoundError(f"No model PDB found in {pred_dir}")

    complex_pdb = pdb_candidates[0]

    # Split
    out_protein_pdb = output_dir / f"{job_name}_protein.pdb"
    out_ligand_pdb = output_dir / f"{job_name}_ligand.pdb"
    split_info = split_complex_pdb(
        complex_pdb=complex_pdb,
        out_protein_pdb=out_protein_pdb,
        out_ligand_pdb=out_ligand_pdb,
        ligand_chain_id=ligand_chain_id,
    )

    # Convert ligand PDB -> SDF for downstream tools
    out_ligand_sdf = output_dir / f"{job_name}_ligand.sdf"
    sdf_info = ligand_pdb_to_sdf(out_ligand_pdb, out_ligand_sdf)

    # Compute box
    box = compute_box_from_ligand(out_ligand_pdb, padding=padding)

    # Read confidence
    conf_files = list(pred_dir.glob(f"confidence_{job_name}_model_{model_index}.json"))
    conf = read_confidence(conf_files[0]) if conf_files else {}

    # Read affinity (one per job)
    aff_files = list(pred_dir.glob(f"affinity_{job_name}.json"))
    aff = read_affinity(aff_files[0]) if aff_files else {}

    summary = {
        "job_name": job_name,
        "model_index": model_index,
        "complex_pdb": str(complex_pdb),
        "protein_pdb": str(out_protein_pdb),
        "ligand_pdb": str(out_ligand_pdb),
        "ligand_sdf": str(out_ligand_sdf),
        "n_protein_atoms": split_info["n_protein_atoms"],
        "n_ligand_atoms": split_info["n_ligand_atoms"],
        "ligand_chain": split_info["ligand_chain"],
        "ligand_resname": split_info["ligand_resname"],
        "box": box,
        "confidence": {k: v for k, v in conf.items() if k != "raw"},
        "affinity": {k: v for k, v in aff.items() if k != "raw"},
    }

    # Save summary JSON
    summary_path = output_dir / f"{job_name}_boltz_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, default=str))
    summary["summary_path"] = str(summary_path)

    return summary


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Usage: python parser.py <predictions_dir> <output_dir> [ligand_chain_id]")
        sys.exit(1)
    chain = sys.argv[3] if len(sys.argv) > 3 else None
    info = parse_boltz_output(sys.argv[1], sys.argv[2], ligand_chain_id=chain)
    print(json.dumps(info, indent=2, default=str))
