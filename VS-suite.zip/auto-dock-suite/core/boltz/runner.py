"""Boltz-2 runner: wraps `boltz predict` via subprocess.

Designed to call Boltz from inside the boltz2 conda env. Handles errors,
captures logs, and returns paths to all output files for downstream parsing.
"""
from pathlib import Path
import subprocess
import time
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def run_boltz(yaml_path,
              output_dir,
              conda_env: str = "boltz2",
              use_msa_server: bool = True,
              use_potentials: bool = True,
              output_format: str = "pdb",
              diffusion_samples: int = 1,
              recycling_steps: int = 3,
              accelerator: str = "gpu",
              devices: int = 1,
              no_kernels: bool = False,
              override: bool = False,
              extra_args: list = None,
              timeout: int = 3600,
              log_path=None,
              stream: bool = True) -> dict:
    """Run Boltz-2 prediction on a single YAML.

    Args:
        yaml_path: path to Boltz YAML input
        output_dir: where Boltz writes its output_dir/predictions/...
        conda_env: env where boltz lives
        use_msa_server: --use_msa_server flag
        use_potentials: --use_potentials flag
        output_format: pdb | mmcif
        diffusion_samples: number of diffusion samples (poses)
        recycling_steps: recycling steps in inference
        accelerator: gpu | cpu | tpu
        devices: number of devices
        no_kernels: pass --no_kernels (for old GPUs / cuequivariance issues)
        override: overwrite existing predictions
        extra_args: list of additional CLI args (advanced)
        timeout: seconds before killing the run
        log_path: file to append the live log to (None = /tmp auto)
        stream: if True, also stream output to stderr live

    Returns:
        dict with paths, returncode, runtime, etc.
    """
    yaml_path = Path(yaml_path).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if not yaml_path.exists():
        raise FileNotFoundError(f"Boltz YAML not found: {yaml_path}")

    if log_path is None:
        log_path = Path(f"/tmp/boltz_{yaml_path.stem}.log")
    else:
        log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Use direct binary path to avoid conda run activation issues
    import shutil
    boltz_bin = shutil.which("boltz") or f"/home/subu/.conda/envs/{conda_env}/bin/boltz"
    # Run with conda run but also set env vars explicitly
    cmd = ["conda", "run", "-n", conda_env, "--no-capture-output",
           boltz_bin, "predict",
           str(yaml_path),
           "--out_dir", str(output_dir),
           "--output_format", output_format,
           "--diffusion_samples", str(diffusion_samples),
           "--recycling_steps", str(recycling_steps),
           "--accelerator", accelerator,
           "--devices", str(devices)]

    if use_msa_server:
        cmd.append("--use_msa_server")
    if use_potentials:
        cmd.append("--use_potentials")
    if no_kernels:
        cmd.append("--no_kernels")
    if override:
        cmd.append("--override")
    if extra_args:
        cmd.extend(extra_args)

    start = time.time()
    log_lines = []

    if stream:
        # Live streaming
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        try:
            for line in proc.stdout:
                log_lines.append(line)
                sys.stderr.write(line)
                sys.stderr.flush()
                if (time.time() - start) > timeout:
                    proc.kill()
                    raise TimeoutError(f"Boltz exceeded {timeout}s timeout")
            proc.wait()
            returncode = proc.returncode
        except Exception:
            proc.kill()
            raise
    else:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        log_lines.append(result.stdout)
        log_lines.append(result.stderr)
        returncode = result.returncode

    elapsed = time.time() - start
    log_path.write_text("".join(log_lines))

    # Locate prediction output dir
    # Boltz writes to: <output_dir>/boltz_results_<yaml_stem>/predictions/<yaml_stem>/
    boltz_results = output_dir / f"boltz_results_{yaml_path.stem}"
    pred_dir = boltz_results / "predictions" / yaml_path.stem

    info = {
        "yaml": str(yaml_path),
        "out_dir": str(output_dir),
        "boltz_results_dir": str(boltz_results),
        "predictions_dir": str(pred_dir) if pred_dir.exists() else None,
        "log_path": str(log_path),
        "returncode": returncode,
        "elapsed_seconds": round(elapsed, 1),
        "command": " ".join(cmd),
    }

    if returncode != 0:
        info["error"] = "Boltz exited non-zero. See log."
        return info

    if not pred_dir.exists():
        info["error"] = f"Predictions dir missing: {pred_dir}"
        return info

    # Catalog produced files
    info["model_files"] = sorted([str(p) for p in pred_dir.glob(f"*model_*.{output_format}")])
    info["confidence_files"] = sorted([str(p) for p in pred_dir.glob("confidence_*.json")])
    info["affinity_files"] = sorted([str(p) for p in pred_dir.glob("affinity_*.json")])
    info["pae_files"] = sorted([str(p) for p in pred_dir.glob("pae_*.npz")])
    info["pde_files"] = sorted([str(p) for p in pred_dir.glob("pde_*.npz")])
    info["plddt_files"] = sorted([str(p) for p in pred_dir.glob("plddt_*.npz")])

    info["success"] = bool(info["model_files"])
    return info


if __name__ == "__main__":
    import json
    if len(sys.argv) < 3:
        print("Usage: python runner.py <yaml> <out_dir> [--no-msa] [--no-potentials] [--no-kernels]")
        sys.exit(1)

    args = sys.argv[3:]
    info = run_boltz(
        sys.argv[1], sys.argv[2],
        use_msa_server="--no-msa" not in args,
        use_potentials="--no-potentials" not in args,
        no_kernels="--no-kernels" in args,
        override="--override" in args,
        stream=True,
    )
    print()
    print("=" * 60)
    print(json.dumps({k: v for k, v in info.items()
                      if k != "command"},
                     indent=2, default=str))
