"""Build Boltz-2 YAML inputs from FASTA + ligand CSV.

Usage:
    from core.boltz.yaml_builder import build_boltz_yamls
    yamls = build_boltz_yamls(
        fasta_path="examples/test_protein.fasta",
        ligands_csv="examples/test_ligands.csv",
        output_dir="results/boltz_inputs",
        chain_mode="monomer",   # or "dimer" / "all"
        compute_affinity=True,
        affinity_max_atoms=128,
    )

Output: list of paths to YAML files, one per ligand.
"""
from pathlib import Path
import csv
import yaml as yamlmod
from rdkit import Chem


def parse_fasta(fasta_path):
    """Parse FASTA -> list of (header, sequence) tuples."""
    fasta_path = Path(fasta_path)
    if not fasta_path.exists():
        raise FileNotFoundError(f"FASTA not found: {fasta_path}")

    records = []
    cur_header = None
    cur_seq = []
    for ln in fasta_path.read_text().splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if ln.startswith(">"):
            if cur_header is not None:
                records.append((cur_header, "".join(cur_seq)))
            cur_header = ln[1:]
            cur_seq = []
        else:
            cur_seq.append(ln.replace(" ", ""))
    if cur_header is not None:
        records.append((cur_header, "".join(cur_seq)))

    if not records:
        raise ValueError(f"No sequences found in {fasta_path}")
    return records


def parse_ligands_csv(csv_path):
    """Parse 2-col CSV (title, smiles) -> list of dicts."""
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"Ligands CSV not found: {csv_path}")

    ligands = []
    with open(csv_path, "r", newline="") as f:
        reader = csv.DictReader(f)
        cols_lower = [c.lower() for c in reader.fieldnames or []]
        if "title" not in cols_lower or "smiles" not in cols_lower:
            raise ValueError(
                f"CSV must have columns: title, smiles. Found: {reader.fieldnames}"
            )
        # Map case-insensitively
        title_key = reader.fieldnames[cols_lower.index("title")]
        smi_key = reader.fieldnames[cols_lower.index("smiles")]
        for i, row in enumerate(reader, 1):
            title = (row[title_key] or "").strip()
            smi = (row[smi_key] or "").strip()
            if not title or not smi:
                continue
            # Basic SMILES validation
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                print(f"[WARN] Row {i} ({title}): invalid SMILES, skipping: {smi}")
                continue
            ligands.append({
                "title": title,
                "smiles": smi,
                "mol": mol,
                "n_atoms_heavy": mol.GetNumHeavyAtoms(),
                "n_atoms_total": Chem.AddHs(mol).GetNumAtoms(),
            })
    return ligands


def build_boltz_yamls(fasta_path,
                     ligands_csv,
                     output_dir,
                     chain_mode: str = "monomer",
                     compute_affinity: bool = True,
                     affinity_max_atoms: int = 128) -> list:
    """Build one Boltz YAML per ligand.

    Args:
        fasta_path: protein FASTA file
        ligands_csv: ligands CSV (title, smiles)
        output_dir: where to save YAMLs
        chain_mode:
            "monomer" - use only first chain in FASTA
            "dimer"   - use first 2 chains (or duplicate first if only 1)
            "all"     - use all chains in FASTA
        compute_affinity: add affinity property to YAML
        affinity_max_atoms: skip affinity if ligand > this atom count

    Returns:
        list of dicts: [{title, yaml_path, n_atoms, affinity_enabled}, ...]
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    proteins = parse_fasta(fasta_path)
    ligands = parse_ligands_csv(ligands_csv)

    if not ligands:
        raise ValueError("No valid ligands parsed from CSV.")

    # Choose chains based on mode
    if chain_mode == "monomer":
        chains_to_use = [proteins[0]]
        protein_chain_ids = ["A"]
    elif chain_mode == "dimer":
        if len(proteins) >= 2:
            chains_to_use = proteins[:2]
            protein_chain_ids = ["A", "B"]
        else:
            # Duplicate the single chain
            chains_to_use = [proteins[0], proteins[0]]
            protein_chain_ids = ["A", "B"]
    elif chain_mode == "all":
        chains_to_use = proteins
        protein_chain_ids = [chr(ord("A") + i) for i in range(len(proteins))]
    else:
        raise ValueError(f"Unknown chain_mode: {chain_mode}")

    # Ligand chain ID is next letter after last protein chain
    ligand_chain_id = chr(ord(protein_chain_ids[-1]) + 1)

    results = []
    for lig in ligands:
        title = lig["title"]
        # Sanitize title for filename
        safe_title = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)
        affinity_ok = compute_affinity and lig["n_atoms_total"] <= affinity_max_atoms

        # Build sequences block
        sequences = []
        for cid, (_, seq) in zip(protein_chain_ids, chains_to_use):
            sequences.append({
                "protein": {
                    "id": cid,
                    "sequence": seq,
                }
            })
        sequences.append({
            "ligand": {
                "id": ligand_chain_id,
                "smiles": lig["smiles"],
            }
        })

        doc = {
            "version": 1,
            "sequences": sequences,
        }
        if affinity_ok:
            doc["properties"] = [{"affinity": {"binder": ligand_chain_id}}]

        yaml_path = output_dir / f"{safe_title}.yaml"
        with open(yaml_path, "w") as f:
            yamlmod.safe_dump(doc, f, sort_keys=False, default_flow_style=False)

        results.append({
            "title": title,
            "safe_title": safe_title,
            "yaml_path": str(yaml_path),
            "n_atoms_heavy": lig["n_atoms_heavy"],
            "n_atoms_total": lig["n_atoms_total"],
            "affinity_enabled": affinity_ok,
            "n_protein_chains": len(chains_to_use),
            "ligand_chain_id": ligand_chain_id,
            "smiles": lig["smiles"],
        })

    return results


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 4:
        print("Usage: python yaml_builder.py <fasta> <ligands.csv> <output_dir> [chain_mode]")
        print("  chain_mode: monomer | dimer | all  (default: monomer)")
        sys.exit(1)

    fasta = sys.argv[1]
    csv_in = sys.argv[2]
    outd = sys.argv[3]
    mode = sys.argv[4] if len(sys.argv) > 4 else "monomer"

    res = build_boltz_yamls(fasta, csv_in, outd, chain_mode=mode)
    print(json.dumps(res, indent=2))
