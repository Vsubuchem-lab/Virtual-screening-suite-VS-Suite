"""GNINA wrapper.

GNINA = Vina-style search + CNN-based scoring/refinement.
Uses same PDBQT inputs as Vina, adds CNN scores.
"""
import sys
import time
import re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.utils.conda_runner import run_binary


def parse_gnina_log(log_text):
    """Extract pose scores from GNINA stdout.

    GNINA v1.x table has 5 columns:
      mode | affinity (kcal/mol) | intramol (kcal/mol) | CNN pose score | CNN affinity (pKd)
      -----+---------------------+---------------------+----------------+--------------------
         1     -9.44                -3.24                  0.5112             6.692

    Sometimes only 4 columns when --cnn_scoring=none. We auto-detect.
    """
    poses = []
    in_table = False
    for ln in log_text.splitlines():
        s = ln.strip()
        if s.startswith("-----+"):
            in_table = True
            continue
        if in_table:
            parts = s.split()
            if len(parts) >= 2 and parts[0].isdigit():
                try:
                    pose = {
                        "mode": int(parts[0]),
                        "affinity_kcal_mol": float(parts[1]),
                    }
                    # 5-column format: affinity, intramol, cnn_pose, cnn_affinity
                    if len(parts) >= 5:
                        pose["intramol_kcal_mol"] = float(parts[2])
                        pose["cnn_pose_score"] = float(parts[3])
                        pose["cnn_affinity_pK"] = float(parts[4])
                    elif len(parts) >= 4:
                        # Could be 4-cols with intramol + cnn_pose, no CNN affinity
                        pose["intramol_kcal_mol"] = float(parts[2])
                        pose["cnn_pose_score"] = float(parts[3])
                    elif len(parts) == 3:
                        pose["intramol_kcal_mol"] = float(parts[2])
                    poses.append(pose)
                except (ValueError, IndexError):
                    pass
            else:
                if poses:
                    in_table = False
    return poses


def run_gnina(receptor_pdbqt,
              ligand_pdbqt,
              output_dir,
              center,
              size,
              cnn_scoring: str = "rescore",
              exhaustiveness: int = 16,
              n_poses: int = 9,
              seed: int = 42,
              cpu: int = 4,
              use_gpu: bool = True,
              timeout: int = 1800,
              tag: str = "gnina") -> dict:
    """Run GNINA docking.

    Args:
        receptor_pdbqt: prepared protein PDBQT
        ligand_pdbqt: prepared ligand PDBQT
        output_dir: where outputs go
        center: [cx, cy, cz] box center
        size: [sx, sy, sz] box size
        cnn_scoring:
            none      - no CNN, pure Vina-style
            rescore   - run Vina search, rescore top poses with CNN
            refinement - use CNN during local refinement
            metrorefine - CNN-guided Metropolis refinement (slow, best)
        exhaustiveness, n_poses, seed: search params
        cpu: CPU threads
        use_gpu: use GPU for CNN scoring
        timeout: kill after seconds
        tag: filename prefix

    Returns:
        dict with paths, poses, runtime
    """
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    output_sdf = output_dir / f"{tag}_poses.sdf"
    log_path = output_dir / f"{tag}_run.log"

    args = [
        "--receptor", str(Path(receptor_pdbqt).resolve()),
        "--ligand", str(Path(ligand_pdbqt).resolve()),
        "--out", str(output_sdf),
        "--center_x", str(center[0]),
        "--center_y", str(center[1]),
        "--center_z", str(center[2]),
        "--size_x", str(size[0]),
        "--size_y", str(size[1]),
        "--size_z", str(size[2]),
        "--exhaustiveness", str(exhaustiveness),
        "--num_modes", str(n_poses),
        "--seed", str(seed),
        "--cpu", str(cpu),
        "--cnn_scoring", cnn_scoring,
    ]

    if not use_gpu:
        args += ["--no_gpu"]

    start = time.time()
    result = run_binary("gnina", args, timeout=timeout)
    elapsed = time.time() - start

    log_path.write_text(
        f"=== CMD ===\ngnina {' '.join(args)}\n\n"
        f"=== STDOUT ===\n{result.stdout}\n\n"
        f"=== STDERR ===\n{result.stderr}\n"
    )

    if result.returncode != 0 or not output_sdf.exists():
        return {
            "tool": "gnina",
            "success": False,
            "returncode": result.returncode,
            "elapsed_seconds": round(elapsed, 1),
            "log": str(log_path),
            "stderr_tail": result.stderr[-1000:],
        }

    poses = parse_gnina_log(result.stdout)

    info = {
        "tool": "gnina",
        "success": True,
        "returncode": result.returncode,
        "elapsed_seconds": round(elapsed, 1),
        "output_sdf": str(output_sdf),
        "log": str(log_path),
        "n_poses": len(poses),
        "best_affinity_kcal_mol": poses[0].get("affinity_kcal_mol") if poses else None,
        "best_cnn_pose_score": poses[0].get("cnn_pose_score") if poses else None,
        "best_cnn_affinity_pK": poses[0].get("cnn_affinity_pK") if poses else None,
        "poses": poses,
        "cnn_scoring": cnn_scoring,
        "box_center": list(center),
        "box_size": list(size),
    }
    return info


if __name__ == "__main__":
    import json
    if len(sys.argv) < 10:
        print("Usage: python gnina.py <receptor.pdbqt> <ligand.pdbqt> <out_dir> cx cy cz sx sy sz")
        sys.exit(1)
    rec, lig, outd = sys.argv[1], sys.argv[2], sys.argv[3]
    center = [float(x) for x in sys.argv[4:7]]
    size = [float(x) for x in sys.argv[7:10]]
    info = run_gnina(rec, lig, outd, center, size)
    print(json.dumps(info, indent=2, default=str))
