"""AutoDock Vina wrapper.

Runs Vina with config built from Boltz parser output (receptor PDBQT + box).
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import time
import re
from core.utils.conda_runner import run_binary


def write_vina_config(receptor_pdbqt,
                       ligand_pdbqt,
                       output_pdbqt,
                       center,
                       size,
                       config_path,
                       exhaustiveness: int = 16,
                       n_poses: int = 9,
                       energy_range: float = 4.0,
                       seed: int = 42,
                       cpu: int = 4) -> Path:
    """Write a Vina config file."""
    config_path = Path(config_path)
    config_path.parent.mkdir(parents=True, exist_ok=True)

    cfg = (
        f"receptor = {Path(receptor_pdbqt).resolve()}\n"
        f"ligand = {Path(ligand_pdbqt).resolve()}\n"
        f"out = {Path(output_pdbqt).resolve()}\n"
        f"center_x = {center[0]}\n"
        f"center_y = {center[1]}\n"
        f"center_z = {center[2]}\n"
        f"size_x = {size[0]}\n"
        f"size_y = {size[1]}\n"
        f"size_z = {size[2]}\n"
        f"exhaustiveness = {exhaustiveness}\n"
        f"num_modes = {n_poses}\n"
        f"energy_range = {energy_range}\n"
        f"seed = {seed}\n"
        f"cpu = {cpu}\n"
    )
    config_path.write_text(cfg)
    return config_path


def parse_vina_log(log_text):
    """Extract pose scores from Vina log output.

    Vina prints a table:
       mode |   affinity | dist from best mode
            | (kcal/mol) | rmsd l.b.| rmsd u.b.
       -----+------------+----------+----------
          1       -8.5      0.000      0.000
          2       -7.9      2.341      4.122
          ...
    """
    poses = []
    in_table = False
    for ln in log_text.splitlines():
        s = ln.strip()
        if s.startswith("-----+"):
            in_table = True
            continue
        if in_table:
            parts = s.split()
            if len(parts) >= 4 and parts[0].isdigit():
                try:
                    poses.append({
                        "mode": int(parts[0]),
                        "affinity_kcal_mol": float(parts[1]),
                        "rmsd_lb": float(parts[2]),
                        "rmsd_ub": float(parts[3]),
                    })
                except ValueError:
                    pass
            else:
                in_table = False
    return poses


def run_vina(receptor_pdbqt,
             ligand_pdbqt,
             output_dir,
             center,
             size,
             exhaustiveness: int = 16,
             n_poses: int = 9,
             energy_range: float = 4.0,
             seed: int = 42,
             cpu: int = 4,
             timeout: int = 1800,
             tag: str = "vina") -> dict:
    """Run AutoDock Vina docking.

    Args:
        receptor_pdbqt: prepared protein PDBQT
        ligand_pdbqt: prepared ligand PDBQT
        output_dir: where outputs go
        center: [cx, cy, cz] box center
        size: [sx, sy, sz] box size in Angstroms
        exhaustiveness, n_poses, energy_range, seed, cpu: Vina params
        timeout: kill after seconds
        tag: filename prefix for outputs

    Returns:
        dict with paths, poses, runtime
    """
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    output_pdbqt = output_dir / f"{tag}_poses.pdbqt"
    config_path = output_dir / f"{tag}_config.txt"
    log_path = output_dir / f"{tag}_run.log"

    write_vina_config(
        receptor_pdbqt=receptor_pdbqt,
        ligand_pdbqt=ligand_pdbqt,
        output_pdbqt=output_pdbqt,
        center=center,
        size=size,
        config_path=config_path,
        exhaustiveness=exhaustiveness,
        n_poses=n_poses,
        energy_range=energy_range,
        seed=seed,
        cpu=cpu,
    )

    start = time.time()
    result = run_binary(
        "vina",
        ["--config", str(config_path)],
        timeout=timeout,
    )
    elapsed = time.time() - start

    log_path.write_text(
        f"=== STDOUT ===\n{result.stdout}\n\n=== STDERR ===\n{result.stderr}\n"
    )

    if result.returncode != 0 or not output_pdbqt.exists():
        return {
            "tool": "vina",
            "success": False,
            "returncode": result.returncode,
            "elapsed_seconds": round(elapsed, 1),
            "log": str(log_path),
            "stderr_tail": result.stderr[-1000:],
        }

    poses = parse_vina_log(result.stdout)

    return {
        "tool": "vina",
        "success": True,
        "returncode": result.returncode,
        "elapsed_seconds": round(elapsed, 1),
        "config": str(config_path),
        "output_pdbqt": str(output_pdbqt),
        "log": str(log_path),
        "n_poses": len(poses),
        "best_affinity_kcal_mol": poses[0]["affinity_kcal_mol"] if poses else None,
        "poses": poses,
        "box_center": list(center),
        "box_size": list(size),
    }


if __name__ == "__main__":
    import json
    if len(sys.argv) < 8:
        print("Usage: python vina.py <receptor.pdbqt> <ligand.pdbqt> <out_dir> cx cy cz sx sy sz")
        sys.exit(1)
    rec, lig, outd = sys.argv[1], sys.argv[2], sys.argv[3]
    center = [float(x) for x in sys.argv[4:7]]
    size = [float(x) for x in sys.argv[7:10]]
    info = run_vina(rec, lig, outd, center, size)
    print(json.dumps(info, indent=2, default=str))
