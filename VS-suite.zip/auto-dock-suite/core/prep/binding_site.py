"""Binding site detection for docking.

Three modes:
  - auto: fpocket detects pockets, returns top-ranked one
  - manual: user supplies center + size
  - from_ligand: derive box from reference ligand position
"""
from pathlib import Path
import json
import shutil
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core.utils.conda_runner import run_in_conda_env


def _load_pocket_info(fpocket_out_dir):
    """Parse fpocket output and return list of pocket dicts sorted by druggability."""
    info_file = fpocket_out_dir / "pockets" / "info.txt"
    if not info_file.exists():
        # Try alternate location
        for f in fpocket_out_dir.rglob("*_info.txt"):
            info_file = f
            break

    pockets = []
    if not info_file.exists():
        return pockets

    text = info_file.read_text()
    blocks = text.split("Pocket")
    for blk in blocks[1:]:
        lines = blk.strip().splitlines()
        if not lines:
            continue
        try:
            pid = int(lines[0].split(":")[0].strip())
        except (ValueError, IndexError):
            continue
        d = {"pocket_id": pid}
        for ln in lines[1:]:
            if ":" in ln:
                k, v = ln.split(":", 1)
                k = k.strip().lower().replace(" ", "_").replace("-", "_")
                try:
                    d[k] = float(v.strip())
                except ValueError:
                    d[k] = v.strip()
        pockets.append(d)

    # Sort by druggability score (high first), fallback to score
    def sort_key(p):
        return (
            p.get("druggability_score", 0.0),
            p.get("score", 0.0),
            p.get("number_of_alpha_spheres", 0.0),
        )
    pockets.sort(key=sort_key, reverse=True)
    return pockets


def _pocket_box_from_atoms(pocket_pdb_path, padding=5.0):
    """Compute box center and size from a pocket atoms PDB file."""
    coords = []
    for ln in Path(pocket_pdb_path).read_text().splitlines():
        if ln.startswith(("ATOM", "HETATM")) and len(ln) >= 54:
            try:
                x = float(ln[30:38])
                y = float(ln[38:46])
                z = float(ln[46:54])
                coords.append((x, y, z))
            except ValueError:
                continue
    if not coords:
        raise RuntimeError(f"No atoms parsed from {pocket_pdb_path}")
    xs, ys, zs = zip(*coords)
    cx = (min(xs) + max(xs)) / 2.0
    cy = (min(ys) + max(ys)) / 2.0
    cz = (min(zs) + max(zs)) / 2.0
    sx = (max(xs) - min(xs)) + 2 * padding
    sy = (max(ys) - min(ys)) + 2 * padding
    sz = (max(zs) - min(zs)) + 2 * padding
    # Cap each dim between 18 and 30 A for typical drug-like ligands
    sx = max(18.0, min(sx, 30.0))
    sy = max(18.0, min(sy, 30.0))
    sz = max(18.0, min(sz, 30.0))
    return [round(cx, 3), round(cy, 3), round(cz, 3)], [round(sx, 1), round(sy, 1), round(sz, 1)]


def detect_binding_site(input_pdb,
                        output_dir,
                        method: str = "auto",
                        manual_center=None,
                        manual_size=None,
                        reference_ligand=None,
                        padding: float = 5.0,
                        conda_env: str = "autodock-prep") -> dict:
    """Detect binding site and produce box coordinates.

    Args:
        input_pdb: prepared protein (PDB or PDBQT)
        output_dir: where to write fpocket output + box JSON
        method: 'auto' | 'manual' | 'from_ligand'
        manual_center: [cx, cy, cz] (only for manual)
        manual_size: [sx, sy, sz] (only for manual)
        reference_ligand: path to a ligand file (only for from_ligand)
        padding: Angstroms around pocket/ligand to include in box
        conda_env: env where fpocket lives

    Returns:
        dict with center, size, method, and metadata
    """
    input_pdb = Path(input_pdb).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_pdb.exists():
        raise FileNotFoundError(f"Input PDB not found: {input_pdb}")

    result_box = {
        "method": method,
        "input_pdb": str(input_pdb),
        "padding": padding,
    }

    if method == "manual":
        if manual_center is None or manual_size is None:
            raise ValueError("manual method requires manual_center and manual_size")
        result_box["center"] = list(map(float, manual_center))
        result_box["size"] = list(map(float, manual_size))

    elif method == "from_ligand":
        if reference_ligand is None:
            raise ValueError("from_ligand method requires reference_ligand path")
        ref = Path(reference_ligand).resolve()
        if not ref.exists():
            raise FileNotFoundError(f"Reference ligand not found: {ref}")
        center, size = _pocket_box_from_atoms(ref, padding=padding)
        result_box["center"] = center
        result_box["size"] = size
        result_box["reference_ligand"] = str(ref)

    elif method == "auto":
        # Run fpocket. It writes output to <input_basename>_out next to input.
        # We will copy input PDB to output_dir to keep things tidy.
        work_pdb = output_dir / input_pdb.name
        if work_pdb.resolve() != input_pdb.resolve():
            shutil.copy2(input_pdb, work_pdb)

        cmd = ["fpocket", "-f", str(work_pdb)]
        result = run_in_conda_env(conda_env, cmd, cwd=output_dir, timeout=600)

        log_out = output_dir / f"{input_pdb.stem}_fpocket.log"
        log_out.write_text(
            f"=== CMD ===\n{' '.join(cmd)}\n\n=== STDOUT ===\n{result.stdout}\n\n=== STDERR ===\n{result.stderr}\n"
        )

        # fpocket writes to <stem>_out/
        fp_dir = output_dir / f"{work_pdb.stem}_out"
        if not fp_dir.exists():
            raise RuntimeError(
                f"fpocket output dir not found: {fp_dir}\n"
                f"stderr tail: {result.stderr[-1000:]}"
            )

        pockets = _load_pocket_info(fp_dir)
        if not pockets:
            raise RuntimeError(
                f"fpocket found no pockets. Check {fp_dir}/pockets/info.txt"
            )

        # Top pocket -> compute box from its atoms
        top = pockets[0]
        pocket_atoms_file = fp_dir / "pockets" / f"pocket{top['pocket_id']}_atm.pdb"
        if not pocket_atoms_file.exists():
            # Try alt naming
            alts = list((fp_dir / "pockets").glob(f"pocket{top['pocket_id']}*.pdb"))
            if alts:
                pocket_atoms_file = alts[0]
            else:
                raise RuntimeError(f"Pocket atoms file missing: {pocket_atoms_file}")

        center, size = _pocket_box_from_atoms(pocket_atoms_file, padding=padding)
        result_box["center"] = center
        result_box["size"] = size
        result_box["fpocket_dir"] = str(fp_dir)
        result_box["fpocket_log"] = str(log_out)
        result_box["top_pocket"] = top
        result_box["n_pockets_found"] = len(pockets)
        result_box["pocket_atoms_file"] = str(pocket_atoms_file)

    else:
        raise ValueError(f"Unknown method: {method}. Use auto | manual | from_ligand")

    # Save box JSON
    box_json = output_dir / f"{input_pdb.stem}_box.json"
    box_json.write_text(json.dumps(result_box, indent=2))
    result_box["box_json"] = str(box_json)

    return result_box


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 3:
        print("Usage: python binding_site.py <protein.pdb> <output_dir> [method] [args...]")
        print("  auto:        python binding_site.py <pdb> <out_dir> auto")
        print("  manual:      python binding_site.py <pdb> <out_dir> manual cx cy cz sx sy sz")
        print("  from_ligand: python binding_site.py <pdb> <out_dir> from_ligand <ligand.pdb>")
        sys.exit(1)

    pdb, outd = sys.argv[1], sys.argv[2]
    method = sys.argv[3] if len(sys.argv) > 3 else "auto"

    if method == "manual":
        if len(sys.argv) < 10:
            print("manual needs: cx cy cz sx sy sz")
            sys.exit(1)
        cx, cy, cz = map(float, sys.argv[4:7])
        sx, sy, sz = map(float, sys.argv[7:10])
        info = detect_binding_site(pdb, outd, "manual",
                                   manual_center=[cx, cy, cz],
                                   manual_size=[sx, sy, sz])
    elif method == "from_ligand":
        if len(sys.argv) < 5:
            print("from_ligand needs: <ligand_path>")
            sys.exit(1)
        info = detect_binding_site(pdb, outd, "from_ligand",
                                   reference_ligand=sys.argv[4])
    else:
        info = detect_binding_site(pdb, outd, "auto")
    print(json.dumps(info, indent=2))
