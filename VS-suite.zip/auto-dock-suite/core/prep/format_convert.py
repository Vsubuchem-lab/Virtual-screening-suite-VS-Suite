"""Convert chemical structure files via OpenBabel.

For malformed SDFs (esp. from older OpenBabel that flags atoms as
explicit-no-implicit-H), automatically does a 2-step round-trip via SMILES
to clean up the chemistry: SDF -> SMILES -> output_format.

CLI:
  python -m core.prep.format_convert input.sdf output.mol2
  python -m core.prep.format_convert input.sdf output.mol2 --force-clean
"""
from pathlib import Path
import sys
import tempfile
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core.utils.conda_runner import run_in_conda_env


def _is_sdf_malformed(sdf_path) -> bool:
    """Quick heuristic: count H atoms in atom block vs heavy atoms.
    If H count is unreasonably low, SDF is likely malformed."""
    try:
        text = Path(sdf_path).read_text()
        lines = text.splitlines()
        if len(lines) < 4:
            return False
        # Counts line is line 4 (0-indexed line 3): "n_atoms n_bonds ..."
        counts = lines[3].split()
        if len(counts) < 2:
            return False
        n_atoms = int(counts[0])
        atom_block = lines[4:4 + n_atoms]
        n_h = sum(1 for ln in atom_block if " H " in ln or ln.endswith(" H"))
        n_heavy = n_atoms - n_h
        # Typical organic mols have H/heavy >= 0.4
        return n_heavy > 5 and (n_h / max(n_heavy, 1)) < 0.4
    except Exception:
        return False


def _run_obabel(args, conda_env: str = "autodock-prep", timeout: int = 300):
    cmd = ["obabel"] + args
    return run_in_conda_env(conda_env, cmd, timeout=timeout)


def convert_format(input_path, output_path,
                   conda_env: str = "autodock-prep",
                   add_hydrogens: bool = False,
                   gen3d: bool = False,
                   force_clean: bool = False) -> dict:
    """Convert chem file via OpenBabel.

    Args:
        force_clean: if True (or auto-detected for malformed SDF), routes
                     conversion through SMILES intermediate to strip bad flags.
    """
    input_path = Path(input_path).resolve()
    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        raise FileNotFoundError(f"Input not found: {input_path}")

    # Auto-detect malformed SDF
    auto_clean = False
    if input_path.suffix.lower() == ".sdf" and _is_sdf_malformed(input_path):
        auto_clean = True

    use_2step = force_clean or auto_clean

    if use_2step:
        # SDF -> SMILES -> output (kills bad flags)
        with tempfile.TemporaryDirectory() as td:
            tmp_smi = Path(td) / "intermediate.smi"
            r1 = _run_obabel([str(input_path), "-osmi", "-O", str(tmp_smi),
                              "--canonical"], conda_env=conda_env)
            if r1.returncode != 0 or not tmp_smi.exists() or tmp_smi.stat().st_size == 0:
                raise RuntimeError(
                    f"Step 1 (SDF -> SMILES) failed: {r1.stderr[-500:]}"
                )

            args2 = [str(tmp_smi), "-O", str(output_path)]
            if gen3d or output_path.suffix.lower() in (".mol2", ".pdb", ".sdf"):
                args2.append("--gen3d")
            if add_hydrogens:
                args2.append("-h")
            r2 = _run_obabel(args2, conda_env=conda_env, timeout=600)
            if r2.returncode != 0 and not output_path.exists():
                raise RuntimeError(
                    f"Step 2 (SMILES -> {output_path.suffix}) failed: {r2.stderr[-500:]}"
                )
            method = "2step_via_smiles"
            stderr_combined = (r1.stderr + r2.stderr)[-1500:]
    else:
        # Direct conversion
        args = [str(input_path), "-O", str(output_path)]
        if add_hydrogens:
            args.append("-h")
        if gen3d:
            args.append("--gen3d")
        r = _run_obabel(args, conda_env=conda_env)
        if r.returncode != 0 or not output_path.exists():
            raise RuntimeError(
                f"OpenBabel conversion failed (code={r.returncode})\n"
                f"stderr: {r.stderr[-1000:]}"
            )
        method = "direct"
        stderr_combined = r.stderr[-500:]

    return {
        "input": str(input_path),
        "output": str(output_path),
        "method": method,
        "auto_cleaned": auto_clean,
        "force_clean": force_clean,
        "size_bytes": output_path.stat().st_size,
    }


if __name__ == "__main__":
    import json
    if len(sys.argv) < 3:
        print("Usage: python -m core.prep.format_convert <input> <output> [--h] [--gen3d] [--force-clean]")
        sys.exit(1)
    info = convert_format(
        sys.argv[1], sys.argv[2],
        add_hydrogens="--h" in sys.argv,
        gen3d="--gen3d" in sys.argv,
        force_clean="--force-clean" in sys.argv,
    )
    print(json.dumps(info, indent=2))
