"""3D embedding + protonation for ligands at pH 7.4.

Pipeline:
  any input -> remove Hs -> protonate at pH -> add Hs -> embed 3D -> minimize

Uses:
  - RDKit for 3D embedding (ETKDG) and MMFF94 minimization
  - OpenBabel (autodock-prep env) for pH-aware protonation (more accurate
    than RDKit for ionizable groups)
"""
from pathlib import Path
import tempfile
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from rdkit import Chem
from rdkit.Chem import AllChem
from core.utils.conda_runner import run_in_conda_env
from core.prep.format_convert import _is_sdf_malformed, convert_format


def protonate_at_ph(mol, ph: float = 7.4, conda_env: str = "autodock-prep"):
    """Protonate a molecule at given pH using OpenBabel.

    OpenBabel's -p flag adjusts protonation state based on standard pKa
    (carboxylic acid -> COO-, primary amine -> NH3+, etc.) at given pH.

    Args:
        mol: RDKit Mol (Hs may or may not be present)
        ph: target pH
        conda_env: env where obabel lives

    Returns:
        RDKit Mol with explicit Hs at correct protonation state
    """
    # Strip existing Hs first to avoid double-counting
    mol_no_h = Chem.RemoveHs(mol)

    # CRITICAL: reset NoImplicit flags - some files (esp. SDFs from older
    # OpenBabel) mark every atom as "explicit, no implicit Hs". After Hs are
    # removed, those atoms still claim "no Hs needed", which corrupts SMILES.
    # We force every atom to recompute valence-based H count.
    rw = Chem.RWMol(mol_no_h)
    for atom in rw.GetAtoms():
        atom.SetNoImplicit(False)
        atom.SetNumExplicitHs(0)
    try:
        Chem.SanitizeMol(rw)
        mol_no_h = rw.GetMol()
    except Exception:
        # If reset breaks the molecule, fall back to original
        pass

    # Use SMILES for transport (no 3D coords) - protonation is a 2D operation
    smi = Chem.MolToSmiles(mol_no_h)

    with tempfile.TemporaryDirectory() as tmpdir:
        in_smi = Path(tmpdir) / "in.smi"
        out_smi = Path(tmpdir) / "out.smi"
        in_smi.write_text(smi + "\n")

        cmd = ["obabel", str(in_smi), "-O", str(out_smi),
               "-p", str(ph)]
        result = run_in_conda_env(conda_env, cmd, timeout=60)

        if result.returncode != 0 or not out_smi.exists():
            # Fallback: just add Hs without pH adjustment
            return Chem.AddHs(mol_no_h)

        protonated_smi = out_smi.read_text().strip().splitlines()[0].split()[0]

    mol_p = Chem.MolFromSmiles(protonated_smi)
    if mol_p is None:
        return Chem.AddHs(mol_no_h)
    mol_p = Chem.AddHs(mol_p)
    return mol_p


def embed_3d(mol, n_conformers: int = 1, optimize: bool = True,
             seed: int = 42) -> "Chem.Mol":
    """Generate 3D conformer(s) using RDKit ETKDG, then optimize with MMFF94.

    Args:
        mol: RDKit Mol with explicit Hs (no 3D coords required)
        n_conformers: how many conformers to generate
        optimize: run MMFF94 minimization
        seed: random seed for reproducibility

    Returns:
        Mol with 3D conformers
    """
    if mol.GetNumAtoms() == 0:
        raise ValueError("Empty molecule cannot be embedded")

    # Make sure Hs are present
    n_h = sum(1 for a in mol.GetAtoms() if a.GetSymbol() == "H")
    if n_h == 0:
        mol = Chem.AddHs(mol)

    params = AllChem.ETKDGv3()
    params.randomSeed = seed
    params.useSmallRingTorsions = True
    params.useMacrocycleTorsions = True

    # If mol already has 3D coords, embed adds new conformers (existing kept)
    cids = AllChem.EmbedMultipleConfs(mol, numConfs=n_conformers, params=params)
    if not cids:
        # Fallback: try with fewer constraints
        params2 = AllChem.ETKDGv3()
        params2.randomSeed = seed
        params2.useRandomCoords = True
        cids = AllChem.EmbedMultipleConfs(mol, numConfs=n_conformers, params=params2)
        if not cids:
            raise RuntimeError("3D embedding failed even with random coords fallback")

    if optimize:
        for cid in cids:
            try:
                AllChem.MMFFOptimizeMolecule(mol, confId=cid, maxIters=500)
            except Exception:
                # MMFF can fail on weird molecules; UFF is a backup
                try:
                    AllChem.UFFOptimizeMolecule(mol, confId=cid, maxIters=500)
                except Exception:
                    pass

    return mol


def prepare_3d_protonated(mol_2d_or_3d, ph: float = 7.4,
                          n_conformers: int = 1, optimize: bool = True,
                          force_reembed: bool = False,
                          seed: int = 42,
                          conda_env: str = "autodock-prep"):
    """Full prep: protonate at pH then ensure 3D coords.

    Args:
        mol_2d_or_3d: RDKit Mol from any source
        ph: protonation pH
        n_conformers: number of 3D conformers to generate
        optimize: run MMFF/UFF minimization
        force_reembed: even if input has 3D, regenerate from scratch
        seed: random seed
        conda_env: env for obabel

    Returns:
        dict {mol, n_confs, was_reembed, ph}
    """
    had_3d = mol_2d_or_3d.GetNumConformers() > 0

    # Step 1: pH-aware protonation (always 2D)
    mol_p = protonate_at_ph(mol_2d_or_3d, ph=ph, conda_env=conda_env)

    # Step 2: Decide whether to re-embed
    # Since protonation went through SMILES, 3D coords are lost - we must re-embed
    # (unless user wants to keep original 3D, which we'd need to handle separately)
    mol_3d = embed_3d(mol_p, n_conformers=n_conformers, optimize=optimize, seed=seed)

    return {
        "mol": mol_3d,
        "n_confs": mol_3d.GetNumConformers(),
        "was_reembed": True,  # always true since protonation strips coords
        "had_input_3d": had_3d,
        "ph": ph,
        "n_atoms_with_h": mol_3d.GetNumAtoms(),
    }


def write_sdf(mol, output_sdf, conf_id: int = 0, name: str = None):
    """Write a single conformer of a Mol to SDF."""
    output_sdf = Path(output_sdf)
    output_sdf.parent.mkdir(parents=True, exist_ok=True)
    if name:
        mol.SetProp("_Name", name)
    writer = Chem.SDWriter(str(output_sdf))
    writer.SetKekulize(True)
    writer.write(mol, confId=conf_id)
    writer.close()
    return output_sdf


if __name__ == "__main__":
    import sys, json
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from core.prep.ligand_reader import read_ligand, mol_summary

    if len(sys.argv) < 3:
        print("Usage: python ligand_3d.py <input> <output.sdf> [ph] [n_confs]")
        sys.exit(1)

    inp = sys.argv[1]
    out = sys.argv[2]
    ph = float(sys.argv[3]) if len(sys.argv) > 3 else 7.4
    nc = int(sys.argv[4]) if len(sys.argv) > 4 else 1

    # Auto-clean malformed SDFs by routing through format_convert
    if str(inp).lower().endswith(".sdf") and _is_sdf_malformed(inp):
        import tempfile
        tmp_clean = Path(tempfile.gettempdir()) / (Path(inp).stem + "_autoclean.mol2")
        print(f"[INFO] Detected malformed SDF. Auto-cleaning via OpenBabel 2-step -> {tmp_clean}")
        convert_format(inp, tmp_clean)
        mol, fmt = read_ligand(str(tmp_clean))
        fmt = "sdf (auto-cleaned)"
    else:
        mol, fmt = read_ligand(inp)
    info_in = mol_summary(mol)

    res = prepare_3d_protonated(mol, ph=ph, n_conformers=nc)
    write_sdf(res["mol"], out, conf_id=0, name=Path(inp).stem)
    info_out = mol_summary(res["mol"])

    report = {
        "input": inp,
        "input_format": fmt,
        "output_sdf": str(out),
        "ph": ph,
        "n_confs": res["n_confs"],
        "before": info_in,
        "after": info_out,
    }
    print(json.dumps(report, indent=2))
