"""Convert ligand SDF/MOL2/PDB to PDBQT for Vina/GNINA via Meeko.

Meeko handles torsion tree, atom typing, and AutoDock charges.
Runs in autodock-prep env (where meeko lives).
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.utils.conda_runner import run_in_conda_env


def ligand_to_pdbqt(input_path,
                    output_pdbqt,
                    conda_env: str = "autodock-prep",
                    keep_chorded_rings: bool = True,
                    rigid_macrocycles: bool = False) -> dict:
    """Convert ligand to PDBQT using Meeko's mk_prepare_ligand.

    Args:
        input_path: SDF/MOL2/PDB
        output_pdbqt: target PDBQT path
        conda_env: env with meeko
        keep_chorded_rings: keep chord (alternative bond) rings as flexible
        rigid_macrocycles: treat large rings as rigid

    Returns:
        dict with paths and stats
    """
    input_path = Path(input_path).resolve()
    output_pdbqt = Path(output_pdbqt).resolve()
    output_pdbqt.parent.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        raise FileNotFoundError(f"Input ligand not found: {input_path}")

    # Build mk_prepare_ligand.py command
    cmd = [
        "mk_prepare_ligand.py",
        "-i", str(input_path),
        "-o", str(output_pdbqt),
    ]
    if rigid_macrocycles:
        cmd.append("--rigid_macrocycles")

    result = run_in_conda_env(conda_env, cmd, timeout=300)

    log_path = output_pdbqt.with_suffix(".meeko.log")
    log_path.write_text(
        f"=== CMD ===\n{' '.join(cmd)}\n\n=== STDOUT ===\n{result.stdout}\n\n=== STDERR ===\n{result.stderr}\n"
    )

    if result.returncode != 0 or not output_pdbqt.exists():
        # Fallback: OpenBabel for simple cases
        fallback_cmd = [
            "obabel", str(input_path),
            "-O", str(output_pdbqt),
            "--partialcharge", "gasteiger",
        ]
        r2 = run_in_conda_env(conda_env, fallback_cmd, timeout=120)
        log_path.write_text(
            log_path.read_text() +
            f"\n=== FALLBACK ===\n{' '.join(fallback_cmd)}\n"
            f"stdout: {r2.stdout}\nstderr: {r2.stderr}\n"
        )
        if r2.returncode != 0 or not output_pdbqt.exists():
            raise RuntimeError(
                f"Both Meeko and OpenBabel failed for {input_path}. "
                f"See log: {log_path}"
            )

    # Stats from PDBQT
    lines = output_pdbqt.read_text().splitlines()
    n_atoms = sum(1 for ln in lines if ln.startswith(("ATOM", "HETATM")))
    n_torsions = sum(1 for ln in lines if ln.startswith("BRANCH"))
    n_roots = sum(1 for ln in lines if ln.startswith("ROOT"))

    return {
        "input": str(input_path),
        "output_pdbqt": str(output_pdbqt),
        "log": str(log_path),
        "n_atoms": n_atoms,
        "n_torsions": n_torsions,
        "n_roots": n_roots,
        "returncode": result.returncode,
    }


if __name__ == "__main__":
    import json
    if len(sys.argv) < 3:
        print("Usage: python ligand_pdbqt.py <input.sdf|mol2|pdb> <output.pdbqt>")
        sys.exit(1)
    info = ligand_to_pdbqt(sys.argv[1], sys.argv[2])
    print(json.dumps(info, indent=2))
