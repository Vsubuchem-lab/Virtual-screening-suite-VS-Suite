"""Universal ligand reader - SMILES, SDF, MOL2, PDB -> RDKit Mol.

Handles auto format detection. SMILES can be raw string or file (.smi/.smiles/.txt).
After reading, runs standardize_mol() so output is consistent across formats.

Note on malformed SDFs:
  Some older SDFs (esp. from older OpenBabel) flag every atom as
  explicit-no-implicit-H, which breaks RDKit's H inference. We detect this
  and emit a UserWarning. Workaround: convert via OpenBabel first using
  core/prep/format_convert.py.
"""
from pathlib import Path
import warnings
from rdkit import Chem
from rdkit.Chem import AllChem


SUPPORTED_FORMATS = {".smi", ".smiles", ".txt", ".sdf", ".mol", ".mol2", ".pdb"}


def detect_format(input_path_or_smiles: str) -> str:
    s = str(input_path_or_smiles)
    p = Path(s)
    if not p.exists():
        if any(ch in s for ch in "()=#[]"):
            return "smiles"
        if all(c.isalpha() or c.isdigit() for c in s):
            return "smiles"
        raise FileNotFoundError(f"Path does not exist and not a SMILES: {s}")
    ext = p.suffix.lower()
    if ext in (".smi", ".smiles", ".txt"):
        return "smiles"
    if ext == ".sdf":
        return "sdf"
    if ext in (".mol", ".mol2"):
        return ext.lstrip(".")
    if ext == ".pdb":
        return "pdb"
    raise ValueError(f"Unsupported ligand format: {ext}")


def read_smiles_file(path):
    text = Path(path).read_text().strip()
    if not text:
        raise ValueError(f"Empty SMILES file: {path}")
    return text.splitlines()[0].strip().split()[0]


def standardize_mol(mol, preserve_3d: bool = True):
    """Strip explicit Hs, re-perceive aromaticity, restore stereo."""
    if mol is None:
        return None
    try:
        mol = Chem.RemoveHs(mol, sanitize=False)
    except Exception:
        pass
    try:
        Chem.SanitizeMol(mol)
    except Exception as e:
        try:
            Chem.SanitizeMol(mol, sanitizeOps=Chem.SANITIZE_ALL ^ Chem.SANITIZE_KEKULIZE)
            Chem.SetAromaticity(mol, Chem.AromaticityModel.AROMATICITY_RDKIT)
        except Exception:
            raise RuntimeError(f"Could not sanitize molecule: {e}")
    if mol.GetNumConformers() > 0 and preserve_3d:
        Chem.AssignStereochemistryFrom3D(mol)
    else:
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
    return mol


def _check_sdf_h_count(mol, sdf_path):
    """Warn if SDF appears to have malformed H-count flags."""
    try:
        m_check = Chem.AddHs(mol)
        n_total_h = sum(1 for a in m_check.GetAtoms() if a.GetSymbol() == "H")
        n_heavy = mol.GetNumHeavyAtoms()
        if n_heavy > 5 and n_total_h < 0.4 * n_heavy:
            warnings.warn(
                f"\n[SDF QUALITY WARNING] {sdf_path}\n"
                f"  Got only {n_total_h} hydrogens for {n_heavy} heavy atoms.\n"
                f"  This SDF likely has explicit-no-implicit atom flags that\n"
                f"  RDKit cannot recover. Workaround: convert via OpenBabel:\n"
                f"    python core/prep/format_convert.py {sdf_path} clean.mol2\n"
                f"  Then pass the .mol2 file to this pipeline.\n",
                UserWarning,
            )
    except Exception:
        pass


def read_ligand(input_path_or_smiles, sanitize: bool = True, standardize: bool = True):
    """Read ligand from any supported format -> (RDKit Mol, format_str)."""
    fmt = detect_format(input_path_or_smiles)

    if fmt == "smiles":
        s = str(input_path_or_smiles)
        smi = read_smiles_file(s) if Path(s).exists() else s.strip()
        mol = Chem.MolFromSmiles(smi, sanitize=sanitize)
        if mol is None:
            raise ValueError(f"RDKit could not parse SMILES: {smi}")

    elif fmt == "sdf":
        suppl = Chem.SDMolSupplier(str(input_path_or_smiles),
                                   removeHs=False, sanitize=sanitize)
        mols = [m for m in suppl if m is not None]
        if not mols:
            raise ValueError(f"No valid molecules in SDF: {input_path_or_smiles}")
        mol = mols[0]
        _check_sdf_h_count(mol, input_path_or_smiles)

    elif fmt == "mol":
        mol = Chem.MolFromMolFile(str(input_path_or_smiles),
                                  removeHs=False, sanitize=sanitize)
        if mol is None:
            raise ValueError(f"Could not read MOL: {input_path_or_smiles}")

    elif fmt == "mol2":
        mol = Chem.MolFromMol2File(str(input_path_or_smiles),
                                   removeHs=False, sanitize=sanitize)
        if mol is None:
            # Fallback via OpenBabel
            import sys as _sys
            _sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
            from core.utils.conda_runner import run_in_conda_env
            tmp_sdf = Path(input_path_or_smiles).with_suffix(".tmp.sdf")
            r = run_in_conda_env("autodock-prep",
                                 ["obabel", str(input_path_or_smiles),
                                  "-O", str(tmp_sdf)],
                                 timeout=120)
            if r.returncode != 0 or not tmp_sdf.exists():
                raise RuntimeError(f"MOL2 read failed via RDKit and OpenBabel.")
            try:
                suppl2 = Chem.SDMolSupplier(str(tmp_sdf), removeHs=False, sanitize=sanitize)
                mols2 = [m for m in suppl2 if m is not None]
                if not mols2:
                    raise ValueError(f"OpenBabel-converted SDF empty: {tmp_sdf}")
                mol = mols2[0]
            finally:
                try:
                    tmp_sdf.unlink()
                except Exception:
                    pass

    elif fmt == "pdb":
        mol = Chem.MolFromPDBFile(str(input_path_or_smiles),
                                  removeHs=False, sanitize=sanitize)
        if mol is None:
            raise ValueError(f"Could not read PDB: {input_path_or_smiles}")
    else:
        raise ValueError(f"Unhandled format: {fmt}")

    if standardize:
        mol = standardize_mol(mol)
    return mol, fmt


def mol_summary(mol) -> dict:
    """Compute descriptors. Adds Hs in-memory for accurate formula/MW."""
    from rdkit.Chem import Descriptors, rdMolDescriptors
    mol_h = Chem.AddHs(mol, addCoords=(mol.GetNumConformers() > 0))
    return {
        "smiles": Chem.MolToSmiles(mol),
        "formula": rdMolDescriptors.CalcMolFormula(mol_h),
        "molecular_weight": round(Descriptors.MolWt(mol_h), 2),
        "n_atoms_with_h": mol_h.GetNumAtoms(),
        "n_heavy_atoms": mol.GetNumHeavyAtoms(),
        "n_rotatable_bonds": rdMolDescriptors.CalcNumRotatableBonds(mol),
        "n_h_donors": rdMolDescriptors.CalcNumHBD(mol),
        "n_h_acceptors": rdMolDescriptors.CalcNumHBA(mol),
        "logp": round(Descriptors.MolLogP(mol), 2),
        "tpsa": round(Descriptors.TPSA(mol), 2),
        "n_aromatic_rings": rdMolDescriptors.CalcNumAromaticRings(mol),
        "has_3d_coords": mol.GetNumConformers() > 0,
    }


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python ligand_reader.py <input_file_or_smiles>")
        sys.exit(1)
    mol, fmt = read_ligand(sys.argv[1])
    info = {"detected_format": fmt}
    info.update(mol_summary(mol))
    print(json.dumps(info, indent=2))
