"""PDB cleaner - strip waters, HETATM, ANISOU, alt locs, etc.

Pure Python (Biopython) - no external tools needed.
Runs in the orchestrator env (autodock-main).
"""
from pathlib import Path
from typing import Optional, List
from Bio.PDB import PDBParser, PDBIO, Select


class CleanSelect(Select):
    """Biopython Select class for filtering atoms during PDB writing."""

    def __init__(self,
                 remove_waters: bool = True,
                 remove_hetatm: bool = True,
                 keep_hetatm_resnames: Optional[List[str]] = None,
                 keep_chains: Optional[List[str]] = None,
                 alt_loc: str = "A"):
        self.remove_waters = remove_waters
        self.remove_hetatm = remove_hetatm
        self.keep_hetatm_resnames = set(keep_hetatm_resnames or [])
        self.keep_chains = set(keep_chains) if keep_chains else None
        self.alt_loc = alt_loc

    def accept_chain(self, chain):
        if self.keep_chains is None:
            return True
        return chain.id in self.keep_chains

    def accept_residue(self, residue):
        hetflag = residue.id[0].strip()
        resname = residue.get_resname().strip()

        if hetflag == "W" or resname in ("HOH", "WAT", "TIP", "TIP3"):
            return not self.remove_waters

        if hetflag.startswith("H_"):
            if resname in self.keep_hetatm_resnames:
                return True
            return not self.remove_hetatm

        return True

    def accept_atom(self, atom):
        if atom.get_altloc() in ("", " ", self.alt_loc):
            return True
        return False


def clean_pdb(input_pdb,
              output_pdb,
              remove_waters: bool = True,
              remove_hetatm: bool = True,
              keep_hetatm_resnames: Optional[List[str]] = None,
              keep_chains: Optional[List[str]] = None,
              alt_loc: str = "A",
              remove_anisou: bool = True) -> dict:
    """Clean a PDB file.

    Returns dict with stats: input/output line counts, what was removed.
    """
    input_pdb = Path(input_pdb)
    output_pdb = Path(output_pdb)
    output_pdb.parent.mkdir(parents=True, exist_ok=True)

    if not input_pdb.exists():
        raise FileNotFoundError(f"Input PDB not found: {input_pdb}")

    # Read input stats
    in_lines = input_pdb.read_text().splitlines()
    n_atom_in = sum(1 for ln in in_lines if ln.startswith("ATOM"))
    n_hetatm_in = sum(1 for ln in in_lines if ln.startswith("HETATM"))
    n_anisou_in = sum(1 for ln in in_lines if ln.startswith("ANISOU"))
    n_water_in = sum(1 for ln in in_lines
                     if ln.startswith(("ATOM", "HETATM"))
                     and ln[17:20].strip() in ("HOH", "WAT", "TIP", "TIP3"))

    # Parse with Biopython
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("input", str(input_pdb))

    # Detect chains
    chains_present = sorted({c.id for m in structure for c in m})

    # Write filtered output (no ANISOU, since PDBIO doesn't write them by default)
    selector = CleanSelect(
        remove_waters=remove_waters,
        remove_hetatm=remove_hetatm,
        keep_hetatm_resnames=keep_hetatm_resnames,
        keep_chains=keep_chains,
        alt_loc=alt_loc,
    )
    io = PDBIO()
    io.set_structure(structure)
    io.save(str(output_pdb), selector)

    # If user explicitly does NOT want ANISOU removed, copy them over
    # (Default behavior is to drop them, which is what we want for docking)

    # Read output stats
    out_lines = output_pdb.read_text().splitlines()
    n_atom_out = sum(1 for ln in out_lines if ln.startswith("ATOM"))
    n_hetatm_out = sum(1 for ln in out_lines if ln.startswith("HETATM"))
    n_anisou_out = sum(1 for ln in out_lines if ln.startswith("ANISOU"))

    stats = {
        "input_path": str(input_pdb),
        "output_path": str(output_pdb),
        "chains_in_input": chains_present,
        "kept_chains": list(keep_chains) if keep_chains else chains_present,
        "atoms_in": n_atom_in,
        "atoms_out": n_atom_out,
        "hetatm_in": n_hetatm_in,
        "hetatm_out": n_hetatm_out,
        "anisou_in": n_anisou_in,
        "anisou_out": n_anisou_out,
        "waters_removed": n_water_in if remove_waters else 0,
    }
    return stats


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 3:
        print("Usage: python pdb_cleaner.py <input.pdb> <output.pdb>")
        sys.exit(1)
    stats = clean_pdb(sys.argv[1], sys.argv[2])
    print(json.dumps(stats, indent=2))
