"""Master protein preparation orchestrator.

Wires together: pdb_cleaner -> protonate -> protein_pdbqt -> binding_site
Returns a single dict with all paths and metadata.
"""
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.prep.pdb_cleaner import clean_pdb
from core.prep.protonate import protonate_protein
from core.prep.protein_pdbqt import protein_to_pdbqt
from core.prep.binding_site import detect_binding_site
from core.utils.logger import setup_logger


def prepare_protein(input_pdb,
                    output_dir,
                    config: dict = None,
                    log=None) -> dict:
    """End-to-end protein preparation.

    Args:
        input_pdb: raw PDB file
        output_dir: directory where all prep outputs go
        config: dict with prep options (see configs/default.yaml -> prep section)
                If None, sensible defaults are used.
        log: optional loguru logger

    Returns:
        dict with all output paths and binding site info, plus a manifest JSON.
    """
    if log is None:
        log = setup_logger(log_dir="logs", log_name="prepare_protein", level="INFO")

    if config is None:
        config = {
            "protein": {
                "remove_waters": True,
                "remove_hetatm": True,
                "keep_chains": None,
                "alt_loc": "A",
                "ph": 7.4,
                "use_propka": True,
            },
            "binding_site": {
                "method": "auto",
                "manual_center": None,
                "manual_size": None,
                "reference_ligand": None,
                "box_padding": 5.0,
            },
        }

    pcfg = config.get("protein", {})
    bcfg = config.get("binding_site", {})

    input_pdb = Path(input_pdb).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_pdb.exists():
        raise FileNotFoundError(f"Input PDB not found: {input_pdb}")

    log.info(f"=== Preparing protein: {input_pdb.name} ===")
    log.info(f"Output dir: {output_dir}")

    # ---- Step 1: Clean PDB ----
    log.info("[Step 1/4] Cleaning PDB (strip waters/HETATM/ANISOU/alt locs)...")
    clean_path = output_dir / f"{input_pdb.stem}_clean.pdb"
    clean_stats = clean_pdb(
        input_pdb=input_pdb,
        output_pdb=clean_path,
        remove_waters=pcfg.get("remove_waters", True),
        remove_hetatm=pcfg.get("remove_hetatm", True),
        keep_chains=pcfg.get("keep_chains"),
        alt_loc=pcfg.get("alt_loc", "A"),
    )
    log.info(f"  Cleaned: atoms {clean_stats['atoms_in']} -> {clean_stats['atoms_out']} "
             f"(ANISOU removed: {clean_stats['anisou_in']})")

    # ---- Step 2: Protonate ----
    log.info("[Step 2/4] Adding hydrogens (PDB2PQR + PROPKA)...")
    proton_info = protonate_protein(
        input_pdb=clean_path,
        output_dir=output_dir,
        ph=pcfg.get("ph", 7.4),
        use_propka=pcfg.get("use_propka", True),
        forcefield="AMBER",
    )
    proton_pdb = Path(proton_info["protonated_pdb"])
    log.info(f"  Hs added: {proton_info['n_hydrogens_added']}")

    # ---- Step 3: PDBQT ----
    log.info("[Step 3/4] Converting to PDBQT (Gasteiger charges)...")
    pdbqt_path = output_dir / f"{input_pdb.stem}.pdbqt"
    pdbqt_info = protein_to_pdbqt(
        input_pdb=proton_pdb,
        output_pdbqt=pdbqt_path,
        rigid=True,
        charge_method="gasteiger",
    )
    log.info(f"  PDBQT atoms: {pdbqt_info['n_atoms']}, "
             f"total charge: {pdbqt_info['total_charge']}")

    # ---- Step 4: Binding site ----
    log.info(f"[Step 4/4] Detecting binding site (method={bcfg.get('method', 'auto')})...")
    bs_dir = output_dir / "binding_site"
    bs_dir.mkdir(exist_ok=True)
    site_info = detect_binding_site(
        input_pdb=proton_pdb,
        output_dir=bs_dir,
        method=bcfg.get("method", "auto"),
        manual_center=bcfg.get("manual_center"),
        manual_size=bcfg.get("manual_size"),
        reference_ligand=bcfg.get("reference_ligand"),
        padding=bcfg.get("box_padding", 5.0),
    )
    log.info(f"  Box center: {site_info['center']}, size: {site_info['size']}")

    # ---- Manifest ----
    manifest = {
        "input_pdb": str(input_pdb),
        "output_dir": str(output_dir),
        "clean_pdb": str(clean_path),
        "clean_stats": clean_stats,
        "protonated_pdb": proton_info["protonated_pdb"],
        "protonated_pqr": proton_info["pqr"],
        "protonation_log": proton_info["log"],
        "pdbqt": str(pdbqt_path),
        "pdbqt_info": pdbqt_info,
        "binding_site": site_info,
        "config_used": config,
    }
    manifest_path = output_dir / f"{input_pdb.stem}_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, default=str))
    manifest["manifest_path"] = str(manifest_path)

    log.info(f"=== Protein prep DONE. Manifest: {manifest_path} ===")
    return manifest


if __name__ == "__main__":
    import sys, json
    from core.utils.config import load_config

    if len(sys.argv) < 3:
        print("Usage: python protein.py <input.pdb> <output_dir> [config.yaml]")
        sys.exit(1)

    cfg = None
    if len(sys.argv) > 3:
        full_cfg = load_config(sys.argv[3])
        cfg = full_cfg.get("prep", {})

    info = prepare_protein(sys.argv[1], sys.argv[2], config=cfg)
    print("\n=== MANIFEST ===")
    print(json.dumps({k: v for k, v in info.items() if k != "config_used"},
                     indent=2, default=str))
