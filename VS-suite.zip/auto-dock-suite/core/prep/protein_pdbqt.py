"""Convert protonated PDB to PDBQT for Vina/GNINA.

Uses OpenBabel (in autodock-prep env) for protein PDB to PDBQT conversion.
Computes Gasteiger partial charges.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core.utils.conda_runner import run_in_conda_env


def protein_to_pdbqt(input_pdb,
                     output_pdbqt,
                     conda_env: str = "autodock-prep",
                     rigid: bool = True,
                     charge_method: str = "gasteiger") -> dict:
    """Convert protonated protein PDB to PDBQT using OpenBabel.

    Args:
        input_pdb: protonated PDB file (with hydrogens)
        output_pdbqt: output PDBQT path
        conda_env: env where obabel lives
        rigid: produce rigid receptor (default True)
        charge_method: gasteiger | mmff94 | eem | none

    Returns:
        dict with paths and stats
    """
    input_pdb = Path(input_pdb).resolve()
    output_pdbqt = Path(output_pdbqt).resolve()
    output_pdbqt.parent.mkdir(parents=True, exist_ok=True)

    if not input_pdb.exists():
        raise FileNotFoundError(f"Input PDB not found: {input_pdb}")

    cmd = [
        "obabel",
        str(input_pdb),
        "-O", str(output_pdbqt),
    ]
    if rigid:
        cmd += ["-xr"]
    cmd += ["-xn"]  # do NOT add new hydrogens (already added by PDB2PQR)

    if charge_method and charge_method.lower() != "none":
        cmd += ["--partialcharge", charge_method]

    result = run_in_conda_env(conda_env, cmd, timeout=300)

    log_path = output_pdbqt.with_suffix(".obabel.log")
    log_path.write_text(
        f"=== CMD ===\n{' '.join(cmd)}\n\n=== STDOUT ===\n{result.stdout}\n\n=== STDERR ===\n{result.stderr}\n"
    )

    if result.returncode != 0 or not output_pdbqt.exists():
        raise RuntimeError(
            f"OpenBabel PDBQT conversion failed (code={result.returncode})\n"
            f"stderr:\n{result.stderr[-1500:]}"
        )

    # Stats
    pdbqt_lines = output_pdbqt.read_text().splitlines()
    n_atom = sum(1 for ln in pdbqt_lines if ln.startswith(("ATOM", "HETATM")))
    n_torsions = sum(1 for ln in pdbqt_lines if ln.startswith("BRANCH"))

    # Charge sanity check - sum charges (column index 70-76 in PDBQT)
    charges = []
    for ln in pdbqt_lines:
        if ln.startswith(("ATOM", "HETATM")) and len(ln) >= 76:
            try:
                charges.append(float(ln[70:76].strip()))
            except ValueError:
                pass
    total_charge = sum(charges) if charges else 0.0
    nonzero_charges = sum(1 for c in charges if abs(c) > 1e-4)

    return {
        "input_pdb": str(input_pdb),
        "output_pdbqt": str(output_pdbqt),
        "log": str(log_path),
        "rigid": rigid,
        "charge_method": charge_method,
        "n_atoms": n_atom,
        "n_torsions": n_torsions,
        "n_nonzero_charges": nonzero_charges,
        "total_charge": round(total_charge, 3),
        "returncode": result.returncode,
    }


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 3:
        print("Usage: python protein_pdbqt.py <protonated.pdb> <output.pdbqt> [charge_method]")
        sys.exit(1)
    cm = sys.argv[3] if len(sys.argv) > 3 else "gasteiger"
    info = protein_to_pdbqt(sys.argv[1], sys.argv[2], charge_method=cm)
    print(json.dumps(info, indent=2))
