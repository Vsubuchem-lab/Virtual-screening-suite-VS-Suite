"""Protonation via PDB2PQR + PROPKA.

Runs PDB2PQR in the autodock-prep conda env (it has pdb2pqr30 + propka3).
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from core.utils.conda_runner import run_in_conda_env


def protonate_protein(input_pdb,
                      output_dir,
                      ph: float = 7.4,
                      use_propka: bool = True,
                      forcefield: str = "AMBER",
                      conda_env: str = "autodock-prep",
                      keep_chain_ids: bool = True) -> dict:
    """Add hydrogens to a clean PDB at given pH using PDB2PQR + PROPKA.

    Args:
        input_pdb: cleaned protein PDB (no waters/HETATM, no Hs)
        output_dir: directory for outputs
        ph: target pH for protonation (default 7.4)
        use_propka: use PROPKA to predict pKa values (recommended)
        forcefield: AMBER | CHARMM | PARSE | TYL06
        conda_env: env where pdb2pqr30 lives
        keep_chain_ids: preserve chain IDs in output

    Returns:
        dict with paths to protonated PDB, PQR, PROPKA file
    """
    input_pdb = Path(input_pdb).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_pdb.exists():
        raise FileNotFoundError(f"Input PDB not found: {input_pdb}")

    stem = input_pdb.stem
    pqr_out = output_dir / f"{stem}_protonated.pqr"
    pdb_out = output_dir / f"{stem}_protonated.pdb"
    propka_out = output_dir / f"{stem}.pka"
    log_out = output_dir / f"{stem}_pdb2pqr.log"

    cmd = [
        "pdb2pqr30",
        "--ff", forcefield,
        "--with-ph", str(ph),
        "--pdb-output", str(pdb_out),
        "--log-level", "INFO",
    ]
    if use_propka:
        cmd += ["--titration-state-method", "propka"]
    if keep_chain_ids:
        cmd += ["--keep-chain"]

    cmd += [str(input_pdb), str(pqr_out)]

    # Run in prep env
    result = run_in_conda_env(conda_env, cmd, timeout=600)

    # Save log
    log_out.write_text(
        f"=== STDOUT ===\n{result.stdout}\n\n=== STDERR ===\n{result.stderr}\n"
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"PDB2PQR failed (code={result.returncode}). "
            f"See log: {log_out}\n\nstderr tail:\n{result.stderr[-1500:]}"
        )

    # PROPKA writes its output to <input_basename>.pka next to where it ran.
    # PDB2PQR places it in CWD; we move it to output_dir if found there.
    if use_propka:
        candidates = [
            Path.cwd() / f"{stem}.pka",
            output_dir / f"{stem}.pka",
            input_pdb.parent / f"{stem}.pka",
        ]
        for c in candidates:
            if c.exists() and c != propka_out:
                propka_out.write_text(c.read_text())
                if c != propka_out:
                    try:
                        c.unlink()
                    except Exception:
                        pass
                break

    if not pqr_out.exists():
        raise RuntimeError(f"PQR file not produced: {pqr_out}")
    if not pdb_out.exists():
        raise RuntimeError(f"Protonated PDB not produced: {pdb_out}")

    # Count Hs added
    n_h = sum(1 for ln in pdb_out.read_text().splitlines()
              if ln.startswith(("ATOM", "HETATM")) and ln[76:78].strip() == "H")

    return {
        "input_pdb": str(input_pdb),
        "protonated_pdb": str(pdb_out),
        "pqr": str(pqr_out),
        "propka": str(propka_out) if propka_out.exists() else None,
        "log": str(log_out),
        "ph": ph,
        "forcefield": forcefield,
        "use_propka": use_propka,
        "n_hydrogens_added": n_h,
        "returncode": result.returncode,
    }


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 3:
        print("Usage: python protonate.py <clean.pdb> <output_dir> [ph]")
        sys.exit(1)
    ph = float(sys.argv[3]) if len(sys.argv) > 3 else 7.4
    info = protonate_protein(sys.argv[1], sys.argv[2], ph=ph)
    print(json.dumps(info, indent=2))
