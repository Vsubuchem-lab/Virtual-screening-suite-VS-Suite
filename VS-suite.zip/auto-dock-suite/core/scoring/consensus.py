"""Consensus scoring across Boltz / Vina / GNINA.

For top-N ligand selection, average ranks across available tools.
Ligands with missing scores get penalized (rank = N+1) for that tool.
"""
from typing import List, Dict, Any


def _get_score(ligand_dict: dict, tool: str):
    """Return the comparable score for a tool, or None if not available.

    Convention: LOWER is better for ranking (we negate where needed):
      - Vina ΔG: already lower-is-better
      - GNINA ΔG: already lower-is-better
      - Boltz P(binder): we negate (higher P → lower negated value)
      - GNINA CNN pK: we negate (higher pK → lower negated value)
      - Boltz log10(IC50): already lower-is-better
    """
    r = (ligand_dict.get("results") or {})
    if tool == "boltz_p":
        v = ((r.get("boltz") or {}).get("affinity") or {}).get("affinity_probability_binary")
        return -v if v is not None else None
    if tool == "boltz_ic50":
        v = ((r.get("boltz") or {}).get("affinity") or {}).get("affinity_pred_value_log10_IC50uM")
        return v
    if tool == "vina":
        return (r.get("vina") or {}).get("best_affinity_kcal_mol")
    if tool == "gnina_dg":
        return (r.get("gnina") or {}).get("best_affinity_kcal_mol")
    if tool == "gnina_pk":
        v = (r.get("gnina") or {}).get("best_cnn_affinity_pK")
        return -v if v is not None else None
    return None


def _rank_by_score(per_ligand: list, tool: str) -> Dict[str, int]:
    """Return {ligand_title: rank} where rank 1 = best.

    Ligands with missing tool scores get rank = N+1.
    Ties get average rank.
    """
    scored = []
    missing = []
    for L in per_ligand:
        title = L.get("title")
        s = _get_score(L, tool)
        if s is None:
            missing.append(title)
        else:
            scored.append((title, s))

    # Sort ascending (lower better after negation convention)
    scored.sort(key=lambda x: x[1])

    ranks = {}
    n = len(scored)
    for i, (title, s) in enumerate(scored):
        ranks[title] = i + 1

    penalty = n + 1
    for title in missing:
        ranks[title] = penalty

    return ranks


def rank_ligands(per_ligand: list, method: str = "consensus") -> list:
    """Rank ligands by the chosen method.

    Args:
        per_ligand: list of ligand result dicts (from results_master.json)
        method: 'consensus' | 'boltz_p' | 'boltz_ic50' | 'vina' | 'gnina_dg' | 'gnina_pk'

    Returns:
        list of dicts: [{title, rank, consensus_rank, breakdown:{...}, ligand_data:{...}}, ...]
        sorted by rank (1 = best).
    """
    if not per_ligand:
        return []

    titles = [L.get("title") for L in per_ligand]

    if method == "consensus":
        # Use 3 metrics: Boltz P(binder), Vina ΔG, GNINA CNN pK
        # If a tool is missing for ALL ligands, drop it from consensus
        sub_methods = ["boltz_p", "vina", "gnina_pk"]
        active = []
        sub_ranks = {}
        for sm in sub_methods:
            r = _rank_by_score(per_ligand, sm)
            # Check whether at least 1 ligand has a real score
            n_real = sum(1 for L in per_ligand if _get_score(L, sm) is not None)
            if n_real > 0:
                active.append(sm)
                sub_ranks[sm] = r

        if not active:
            return []

        # Average rank across active tools
        avg_ranks = {}
        for title in titles:
            ranks = [sub_ranks[sm][title] for sm in active]
            avg_ranks[title] = sum(ranks) / len(ranks)

        # Build output
        rows = []
        for L in per_ligand:
            t = L.get("title")
            br = {sm: sub_ranks[sm][t] for sm in active}
            rows.append({
                "title": t,
                "consensus_rank": avg_ranks[t],
                "breakdown": br,
                "ligand_data": L,
            })
        rows.sort(key=lambda r: r["consensus_rank"])
        for i, row in enumerate(rows):
            row["rank"] = i + 1
        return rows

    else:
        ranks = _rank_by_score(per_ligand, method)
        rows = []
        for L in per_ligand:
            t = L.get("title")
            rows.append({
                "title": t,
                "consensus_rank": ranks[t],
                "breakdown": {method: ranks[t]},
                "ligand_data": L,
            })
        rows.sort(key=lambda r: r["consensus_rank"])
        for i, row in enumerate(rows):
            row["rank"] = i + 1
        return rows


def make_ranking_csv(ranked_rows: list) -> str:
    """Build a CSV string with columns: rank, title, smiles, scores, consensus_rank."""
    import io, csv
    out = io.StringIO()
    fields = [
        "rank", "title", "smiles",
        "boltz_p_binder", "boltz_ic50_uM",
        "vina_best_dG", "gnina_best_dG", "gnina_cnn_pK",
        "consensus_rank",
    ]
    w = csv.DictWriter(out, fieldnames=fields)
    w.writeheader()
    for r in ranked_rows:
        L = r["ligand_data"]
        res = L.get("results") or {}
        b = res.get("boltz") or {}
        aff = b.get("affinity") or {}
        v = res.get("vina") or {}
        g = res.get("gnina") or {}
        w.writerow({
            "rank": r["rank"],
            "title": L.get("title"),
            "smiles": L.get("smiles"),
            "boltz_p_binder": aff.get("affinity_probability_binary"),
            "boltz_ic50_uM": aff.get("ic50_uM"),
            "vina_best_dG": v.get("best_affinity_kcal_mol"),
            "gnina_best_dG": g.get("best_affinity_kcal_mol"),
            "gnina_cnn_pK": g.get("best_cnn_affinity_pK"),
            "consensus_rank": round(r["consensus_rank"], 3),
        })
    return out.getvalue()
