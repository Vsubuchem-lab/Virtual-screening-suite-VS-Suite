"""Run commands inside named conda environments via subprocess."""
import subprocess
import shutil
from pathlib import Path


def run_in_conda_env(env_name, command, cwd=None, timeout=3600):
    """Run a command inside a named conda environment.

    Args:
        env_name: name of conda env (e.g., 'boltz2', 'gnina')
        command: list of command tokens, e.g. ['boltz', 'predict', 'in.yaml']
        cwd: working directory
        timeout: max seconds

    Returns:
        subprocess.CompletedProcess
    """
    full_cmd = ["conda", "run", "-n", env_name, "--no-capture-output"] + command
    return subprocess.run(
        full_cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def run_binary(binary, args, cwd=None, timeout=3600):
    """Run a binary that's already in PATH (e.g., vina, gnina)."""
    full_cmd = [binary] + args
    return subprocess.run(
        full_cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def check_tool_available(tool_name, kind="binary", env_name=None):
    """Check if a tool is callable.

    kind: 'binary' (in PATH) or 'conda' (in named env)
    """
    if kind == "binary":
        return shutil.which(tool_name) is not None
    elif kind == "conda":
        result = run_in_conda_env(env_name, ["which", tool_name], timeout=30)
        return result.returncode == 0
    return False
