"""Centralized logger using loguru."""
from loguru import logger
from pathlib import Path
import sys


def setup_logger(log_dir="logs", log_name="autodock", level="INFO"):
    """Configure loguru logger with console + file sinks."""
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    logger.remove()

    logger.add(
        sys.stderr,
        level=level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
               "<level>{level: <8}</level> | "
               "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
               "<level>{message}</level>",
        colorize=True,
    )

    logger.add(
        log_dir / f"{log_name}.log",
        level=level,
        rotation="50 MB",
        retention="30 days",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | "
               "{name}:{function}:{line} - {message}",
    )

    return logger
