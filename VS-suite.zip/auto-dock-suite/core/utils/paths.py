"""Project path management."""
from pathlib import Path
from dataclasses import dataclass


@dataclass
class ProjectPaths:
    root: Path
    inputs: Path
    prep: Path
    boltz: Path
    vina: Path
    gnina: Path
    scoring: Path
    reports: Path
    logs: Path

    @classmethod
    def from_root(cls, root):
        root = Path(root).resolve()
        p = cls(
            root=root,
            inputs=root / "inputs",
            prep=root / "prep",
            boltz=root / "boltz",
            vina=root / "vina",
            gnina=root / "gnina",
            scoring=root / "scoring",
            reports=root / "reports",
            logs=root / "logs",
        )
        for d in [p.inputs, p.prep, p.boltz, p.vina, p.gnina,
                  p.scoring, p.reports, p.logs]:
            d.mkdir(parents=True, exist_ok=True)
        return p
