"""Extract top-1 pose from each tool's output and convert to SDF.

Used by GUI bulk-download buttons.
"""
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from core.utils.conda_runner import run_in_conda_env


def split_vina_pdbqt(pdbqt_path) -> list:
    """Split a multi-pose Vina PDBQT into individual model PDBQT strings.

    Returns list of strings, one per MODEL block.
    """
    text = Path(pdbqt_path).read_text()
    models = []
    cur = []
    in_model = False
    for ln in text.splitlines():
        if ln.startswith("MODEL"):
            in_model = True
            cur = [ln]
        elif ln.startswith("ENDMDL"):
            cur.append(ln)
            models.append("\n".join(cur))
            cur = []
            in_model = False
        elif in_model:
            cur.append(ln)
    if not models and text.strip():
        # Single-pose PDBQT (no MODEL wrapper)
        models = [text]
    return models


def extract_vina_top_as_sdf(pdbqt_path,
                            output_sdf,
                            conda_env: str = "autodock-prep") -> Path:
    """Extract pose 1 from Vina PDBQT and convert to SDF.

    Uses OpenBabel: obabel pose1.pdbqt -O out.sdf
    """
    pdbqt_path = Path(pdbqt_path)
    output_sdf = Path(output_sdf)
    output_sdf.parent.mkdir(parents=True, exist_ok=True)

    models = split_vina_pdbqt(pdbqt_path)
    if not models:
        raise RuntimeError(f"No models found in {pdbqt_path}")

    with tempfile.TemporaryDirectory() as td:
        single = Path(td) / "pose1.pdbqt"
        single.write_text(models[0])
        r = run_in_conda_env(
            conda_env,
            ["obabel", str(single), "-O", str(output_sdf)],
            timeout=60,
        )
        if r.returncode != 0 or not output_sdf.exists():
            raise RuntimeError(
                f"OpenBabel pose conversion failed: {r.stderr[-500:]}"
            )
    return output_sdf


def extract_gnina_top_as_sdf(gnina_sdf_path, output_sdf) -> Path:
    """GNINA already writes SDF with one molecule per pose, ranked.

    We just take the first molecule.
    """
    from rdkit import Chem
    output_sdf = Path(output_sdf)
    output_sdf.parent.mkdir(parents=True, exist_ok=True)

    suppl = Chem.SDMolSupplier(str(gnina_sdf_path), removeHs=False)
    mols = [m for m in suppl if m is not None]
    if not mols:
        raise RuntimeError(f"No molecules in {gnina_sdf_path}")

    writer = Chem.SDWriter(str(output_sdf))
    writer.write(mols[0])
    writer.close()
    return output_sdf


def copy_boltz_pose(boltz_sdf_path, output_sdf) -> Path:
    """Boltz produces one pose - just copy."""
    import shutil
    output_sdf = Path(output_sdf)
    output_sdf.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(boltz_sdf_path, output_sdf)
    return output_sdf
