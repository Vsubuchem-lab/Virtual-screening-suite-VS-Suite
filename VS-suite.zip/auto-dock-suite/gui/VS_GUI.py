"""VS-Suite GUI - Streamlit interface.

Virtual Screening Suite developed by Centre for Advanced Computation and
Theoretical Sciences (ACTS), SRMIST.

Run with:
    conda activate autodock-main
    streamlit run gui/app.py
"""
import streamlit as st
import pandas as pd
import json
import sys
import time
import threading
import io
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.pipeline import run_pipeline
from core.scoring.consensus import rank_ligands, make_ranking_csv
from core.utils.pose_extract import (
    extract_vina_top_as_sdf,
    extract_gnina_top_as_sdf,
    copy_boltz_pose,
)


# ---------- PAGE CONFIG ----------
st.set_page_config(
    page_title="VS-Suite",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS
st.markdown("""
<style>
    .main > div { padding-top: 0.5rem; }
    .stMetric { background: #f0f2f6; padding: 1rem; border-radius: 0.5rem; }
    div[data-testid="stMetricValue"] { font-size: 1.5rem; }
    .vss-banner {
        background: linear-gradient(90deg, #2C5F2D 0%, #4a8b3f 100%);
        color: white; padding: 0.9rem 1.2rem; border-radius: 8px;
        margin-bottom: 1.2rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .vss-banner-title {
        font-size: 1.45rem; font-weight: 700; margin-bottom: 0.15rem;
        letter-spacing: 0.3px;
    }
    .vss-banner-sub {
        font-size: 0.92rem; opacity: 0.95; line-height: 1.35;
    }
    .vss-footer {
        text-align: center; color: #6B7280; font-size: 0.75rem;
        margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #E5E7EB;
    }
</style>
""", unsafe_allow_html=True)


def render_header():
    """Header banner shown on every page."""
    st.markdown("""
    <div class="vss-banner">
      <div class="vss-banner-title">🧬 VS-Suite</div>
      <div class="vss-banner-sub">
        Virtual Screening-Suite — developed by
        <strong>Centre for Advanced Computation and Theoretical Sciences (ACTS), SRMIST</strong>
      </div>
    </div>
    """, unsafe_allow_html=True)


def render_footer():
    st.markdown(
        '<div class="vss-footer">© Centre for Advanced Computation and Theoretical Sciences (ACTS), SRMIST &nbsp;•&nbsp; '
        'Powered by Boltz-2, AutoDock Vina, and GNINA</div>',
        unsafe_allow_html=True,
    )


# ---------- SESSION STATE ----------
if "run_state" not in st.session_state:
    st.session_state.run_state = "idle"
if "run_thread" not in st.session_state:
    st.session_state.run_thread = None
if "run_result" not in st.session_state:
    st.session_state.run_result = None
if "run_error" not in st.session_state:
    st.session_state.run_error = None


# ---------- SIDEBAR ----------
st.sidebar.title("🧬 VS-Suite")
st.sidebar.caption("Virtual Screening Suite")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    ["🏠 New Run", "📊 Results Browser", "ℹ️ About"],
)


# ---------- HELPERS ----------
def render_results_table(per_ligand):
    rows = []
    for L in per_ligand:
        b = (L.get("results") or {}).get("boltz") or {}
        v = (L.get("results") or {}).get("vina") or {}
        g = (L.get("results") or {}).get("gnina") or {}
        aff = b.get("affinity") or {}
        conf = b.get("confidence") or {}
        rows.append({
            "Ligand": L.get("title"),
            "Boltz IC50 (uM)": aff.get("ic50_uM"),
            "Boltz P(binder)": aff.get("affinity_probability_binary"),
            "Boltz ipTM": conf.get("iptm"),
            "Vina dG (kcal/mol)": v.get("best_affinity_kcal_mol"),
            "GNINA dG (kcal/mol)": g.get("best_affinity_kcal_mol"),
            "GNINA CNN pose": g.get("best_cnn_pose_score"),
            "GNINA CNN pK": g.get("best_cnn_affinity_pK"),
        })
    return pd.DataFrame(rows)


def display_3d_viewer(pdb_text, ligand_text=None, height=400):
    try:
        import py3Dmol
        view = py3Dmol.view(width=700, height=height)
        view.addModel(pdb_text, "pdb")
        view.setStyle({"hetflag": False}, {"cartoon": {"color": "spectrum"}})
        if ligand_text:
            view.addModel(ligand_text, "pdb")
            view.setStyle({"hetflag": True}, {"stick": {"colorscheme": "magentaCarbon"}})
        view.zoomTo()
        view.spin(False)
        html = view._make_html()
        st.components.v1.html(html, height=height + 20)
    except Exception as e:
        st.error(f"3D viewer error: {e}")


def pipeline_worker(args, state):
    try:
        state["status"] = "running"
        result = run_pipeline(**args)
        state["result"] = result
        state["status"] = "done"
    except Exception as e:
        import traceback
        state["error"] = str(e)
        state["trace"] = traceback.format_exc()
        state["status"] = "error"


def build_top10_all_poses_zip(master, top_n: int = 10) -> bytes:
    """Build ZIP: top-N ligands with all poses from all tools."""
    per_ligand = master.get("per_ligand", [])
    ranked = rank_ligands(per_ligand, method="consensus")
    top = ranked[:top_n]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # Ranking CSV at root
        zf.writestr("ranking.csv", make_ranking_csv(top))

        # Manifest
        manifest = {
            "vs_suite_version": "0.1",
            "ranking_method": "consensus (avg rank of Boltz P, Vina dG, GNINA pK)",
            "n_ligands_in_zip": len(top),
        }
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

        for r in top:
            rank = r["rank"]
            title = r["title"]
            safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)
            folder = f"{rank:02d}_{safe}"
            L = r["ligand_data"]
            res = L.get("results") or {}
            b = res.get("boltz") or {}
            v = res.get("vina") or {}
            g = res.get("gnina") or {}

            # Boltz files
            for key, dst in [
                ("complex_pdb", "boltz_complex.pdb"),
                ("protein_pdb", "boltz_protein.pdb"),
                ("ligand_sdf", "boltz_ligand.sdf"),
                ("ligand_pdb", "boltz_ligand.pdb"),
                ("summary_path", "boltz_summary.json"),
            ]:
                p = b.get(key)
                if p and Path(p).exists():
                    zf.write(p, f"{folder}/{dst}")

            # Vina poses
            v_path = v.get("output_pdbqt")
            if v_path and Path(v_path).exists():
                zf.write(v_path, f"{folder}/vina_poses.pdbqt")

            # GNINA poses
            g_path = g.get("output_sdf")
            if g_path and Path(g_path).exists():
                zf.write(g_path, f"{folder}/gnina_poses.sdf")

            # Per-ligand scores JSON
            scores = {
                "rank": rank,
                "title": title,
                "smiles": L.get("smiles"),
                "boltz_affinity": b.get("affinity"),
                "boltz_confidence": b.get("confidence"),
                "vina": {
                    "best_dG": v.get("best_affinity_kcal_mol"),
                    "n_poses": v.get("n_poses"),
                    "poses": v.get("poses"),
                },
                "gnina": {
                    "best_dG": g.get("best_affinity_kcal_mol"),
                    "best_cnn_pose_score": g.get("best_cnn_pose_score"),
                    "best_cnn_affinity_pK": g.get("best_cnn_affinity_pK"),
                    "n_poses": g.get("n_poses"),
                    "poses": g.get("poses"),
                },
                "consensus_rank": r["consensus_rank"],
                "breakdown_ranks": r["breakdown"],
            }
            zf.writestr(f"{folder}/scores.json", json.dumps(scores, indent=2, default=str))

    buf.seek(0)
    return buf.getvalue()


def build_top20_best_poses_zip(master, top_n: int = 20) -> bytes:
    """Build ZIP: top-N ligands, just the BEST pose from each tool (one each)."""
    per_ligand = master.get("per_ligand", [])
    ranked = rank_ligands(per_ligand, method="consensus")
    top = ranked[:top_n]

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("ranking.csv", make_ranking_csv(top))

        manifest = {
            "vs_suite_version": "0.1",
            "ranking_method": "consensus (avg rank of Boltz P, Vina dG, GNINA pK)",
            "n_ligands_in_zip": len(top),
            "contents": "Top pose (mode 1) from each tool, per ligand",
        }
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

        for r in top:
            rank = r["rank"]
            title = r["title"]
            safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)
            stem = f"{rank:02d}_{safe}"
            L = r["ligand_data"]
            res = L.get("results") or {}
            b = res.get("boltz") or {}
            v = res.get("vina") or {}
            g = res.get("gnina") or {}

            # BOLTZ top pose
            b_sdf = b.get("ligand_sdf")
            if b_sdf and Path(b_sdf).exists():
                zf.write(b_sdf, f"boltz/{stem}_boltz_pose.sdf")

            # VINA top pose - need to extract pose 1 from PDBQT, convert to SDF
            v_pdbqt = v.get("output_pdbqt")
            if v_pdbqt and Path(v_pdbqt).exists():
                try:
                    import tempfile
                    with tempfile.NamedTemporaryFile(suffix=".sdf", delete=False) as tmp:
                        tmp_sdf_path = Path(tmp.name)
                    extract_vina_top_as_sdf(v_pdbqt, tmp_sdf_path)
                    if tmp_sdf_path.exists():
                        zf.write(tmp_sdf_path, f"vina/{stem}_vina_top.sdf")
                        tmp_sdf_path.unlink()
                except Exception as e:
                    zf.writestr(f"vina/{stem}_ERROR.txt", f"Vina pose extraction failed: {e}")

            # GNINA top pose - take first from existing SDF
            g_sdf = g.get("output_sdf")
            if g_sdf and Path(g_sdf).exists():
                try:
                    import tempfile
                    with tempfile.NamedTemporaryFile(suffix=".sdf", delete=False) as tmp:
                        tmp_sdf_path = Path(tmp.name)
                    extract_gnina_top_as_sdf(g_sdf, tmp_sdf_path)
                    if tmp_sdf_path.exists():
                        zf.write(tmp_sdf_path, f"gnina/{stem}_gnina_top.sdf")
                        tmp_sdf_path.unlink()
                except Exception as e:
                    zf.writestr(f"gnina/{stem}_ERROR.txt", f"GNINA pose extraction failed: {e}")

    buf.seek(0)
    return buf.getvalue()


# =================================================================
# PAGE: NEW RUN
# =================================================================
if page == "🏠 New Run":
    render_header()
    st.title("New Run")
    st.caption("Boltz-2 -> Vina -> GNINA on a protein + ligand library")

    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("1. Inputs")
        fasta_file = st.file_uploader("Protein FASTA", type=["fasta", "fa", "txt"])
        ligands_file = st.file_uploader("Ligands CSV", type=["csv"],
                                        help="2 columns: title, smiles")
        run_name = st.text_input("Run name",
                                 value=f"run_{time.strftime('%Y%m%d_%H%M')}")

    with col2:
        st.subheader("2. Settings")
        chain_mode = st.selectbox("Protein mode",
                                   ["monomer", "dimer", "all"], index=0)
        use_msa = st.checkbox("Use MSA server", value=True)
        use_potentials = st.checkbox("Use Boltz potentials", value=True)
        col_a, col_b = st.columns(2)
        with col_a:
            run_vina = st.checkbox("Run Vina", value=True)
        with col_b:
            run_gnina = st.checkbox("Run GNINA", value=True)

        with st.expander("Advanced"):
            diffusion_samples = st.slider("Diffusion samples", 1, 5, 1)
            recycling = st.slider("Recycling steps", 1, 10, 3)
            vina_ex = st.slider("Vina exhaustiveness", 4, 32, 16, 4)
            no_kernels = st.checkbox("--no_kernels (for old GPUs)", value=False)
            compute_affinity = st.checkbox("Compute Boltz affinity", value=True)

    st.markdown("---")
    if ligands_file is not None:
        try:
            preview_df = pd.read_csv(ligands_file)
            ligands_file.seek(0)
            st.subheader("3. Ligand Preview")
            st.dataframe(preview_df.head(20), use_container_width=True)
            st.caption(f"Total ligands: {len(preview_df)}")
        except Exception as e:
            st.warning(f"CSV preview failed: {e}")

    st.markdown("---")
    if st.button("🚀 Run Pipeline", type="primary",
                 disabled=(not fasta_file or not ligands_file or
                           st.session_state.run_state == "running")):
        if fasta_file is None or ligands_file is None:
            st.error("Please upload both FASTA and CSV files")
        else:
            output_dir = ROOT / "results" / run_name
            output_dir.mkdir(parents=True, exist_ok=True)

            fasta_path = output_dir / "input_protein.fasta"
            csv_path = output_dir / "input_ligands.csv"
            fasta_path.write_bytes(fasta_file.getvalue())
            csv_path.write_bytes(ligands_file.getvalue())

            args = dict(
                fasta=str(fasta_path),
                ligands_csv=str(csv_path),
                output_dir=str(output_dir),
                chain_mode=chain_mode,
                use_msa=use_msa,
                use_potentials=use_potentials,
                diffusion_samples=diffusion_samples,
                recycling_steps=recycling,
                no_kernels=no_kernels,
                run_vina=run_vina,
                run_gnina=run_gnina,
                vina_exhaustiveness=vina_ex,
                compute_affinity=compute_affinity,
            )

            state = {"status": "running", "result": None, "error": None}
            st.session_state.run_state_dict = state
            t = threading.Thread(target=pipeline_worker, args=(args, state), daemon=True)
            t.start()
            st.session_state.run_thread = t
            st.session_state.run_state = "running"
            st.session_state.current_run_dir = str(output_dir)
            st.rerun()

    if st.session_state.run_state == "running":
        state = st.session_state.run_state_dict
        st.info("Pipeline running. Refresh to update progress.")

        run_dir = Path(st.session_state.current_run_dir)
        master_path = run_dir / "results_master.json"

        if master_path.exists():
            try:
                m = json.loads(master_path.read_text())
                done = m.get("n_completed", 0)
                total = m.get("n_ligands", 1)
                pct = done / total if total else 0
                st.progress(pct, text=f"Ligands done: {done}/{total}")
                if m.get("per_ligand"):
                    st.dataframe(render_results_table(m["per_ligand"]),
                                 use_container_width=True)
            except Exception:
                pass

        log_path = run_dir / "logs" / "pipeline.log"
        if log_path.exists():
            with st.expander("Live log (last 50 lines)"):
                lines = log_path.read_text().splitlines()[-50:]
                st.code("\n".join(lines))

        if state["status"] == "done":
            st.session_state.run_state = "done"
            st.session_state.run_result = state["result"]
            st.success("Pipeline complete")
            st.rerun()
        elif state["status"] == "error":
            st.session_state.run_state = "error"
            st.session_state.run_error = state.get("error", "unknown")
            st.error(f"Pipeline failed: {state.get('error')}")
            with st.expander("Trace"):
                st.code(state.get("trace", ""))
        else:
            time.sleep(2)
            st.rerun()

    elif st.session_state.run_state == "done":
        result = st.session_state.run_result
        st.success(f"Pipeline done in {result['elapsed_seconds']/60:.1f} min")
        df = render_results_table(result["per_ligand"])
        st.subheader("Results")
        st.dataframe(df, use_container_width=True)

    render_footer()


# =================================================================
# PAGE: RESULTS BROWSER
# =================================================================
elif page == "📊 Results Browser":
    render_header()
    st.title("Results Browser")

    results_root = ROOT / "results"
    if not results_root.exists():
        st.warning("No results yet. Run the pipeline first.")
        render_footer()
        st.stop()

    runs = sorted([d for d in results_root.iterdir()
                   if d.is_dir() and (d / "results_master.json").exists()],
                  key=lambda p: p.stat().st_mtime, reverse=True)
    if not runs:
        st.warning("No completed runs found.")
        render_footer()
        st.stop()

    run_names = [r.name for r in runs]
    sel = st.selectbox("Select a run", run_names)
    run_dir = results_root / sel
    master_path = run_dir / "results_master.json"

    try:
        master = json.loads(master_path.read_text())
    except Exception as e:
        st.error(f"Could not read master JSON: {e}")
        render_footer()
        st.stop()

    st.markdown(f"**Run:** `{sel}`")
    cols = st.columns(4)
    cols[0].metric("Ligands", master.get("n_ligands", 0))
    cols[1].metric("Completed", master.get("n_completed", master.get("n_ligands", 0)))
    cols[2].metric("Mode", master.get("chain_mode", "-"))
    cols[3].metric("Elapsed (min)",
                   round((master.get("elapsed_seconds") or 0)/60, 1))

    df = render_results_table(master["per_ligand"])
    st.dataframe(df, use_container_width=True)

    # ---------- BULK DOWNLOADS ----------
    st.markdown("---")
    st.subheader("📥 Bulk Downloads (ranked by consensus across Boltz + Vina + GNINA)")
    st.caption("Consensus rank = average of (Boltz P-binder rank, Vina dG rank, GNINA CNN pK rank).")

    bcol1, bcol2 = st.columns(2)

    n_lig = len(master.get("per_ligand", []))

    with bcol1:
        st.markdown("**📦 Top 10 Ligands — All Poses**")
        st.caption(f"All Boltz/Vina/GNINA poses for the top {min(10, n_lig)} ligands. Best for review.")
        if st.button("Build Top-10 ZIP", key="top10_btn"):
            with st.spinner("Building ZIP (10-30 sec)..."):
                try:
                    zip_bytes = build_top10_all_poses_zip(master, top_n=10)
                    st.download_button(
                        "⬇️ Download top10_all_poses.zip",
                        data=zip_bytes,
                        file_name=f"{sel}_top10_all_poses.zip",
                        mime="application/zip",
                        type="primary",
                    )
                    st.success(f"ZIP ready ({len(zip_bytes) / 1024:.0f} KB)")
                except Exception as e:
                    st.error(f"ZIP build failed: {e}")

    with bcol2:
        st.markdown("**📦 Top 20 Ligands — Best Pose Each**")
        st.caption(f"One pose per tool for top {min(20, n_lig)} ligands. Compact for MD prioritization.")
        if st.button("Build Top-20 ZIP", key="top20_btn"):
            with st.spinner("Building ZIP (30-60 sec)..."):
                try:
                    zip_bytes = build_top20_best_poses_zip(master, top_n=20)
                    st.download_button(
                        "⬇️ Download top20_best_poses.zip",
                        data=zip_bytes,
                        file_name=f"{sel}_top20_best_poses.zip",
                        mime="application/zip",
                        type="primary",
                    )
                    st.success(f"ZIP ready ({len(zip_bytes) / 1024:.0f} KB)")
                except Exception as e:
                    st.error(f"ZIP build failed: {e}")

    # Show ranking CSV preview
    with st.expander("Preview consensus ranking"):
        try:
            ranked = rank_ligands(master.get("per_ligand", []), method="consensus")
            csv_text = make_ranking_csv(ranked)
            preview_df = pd.read_csv(io.StringIO(csv_text))
            st.dataframe(preview_df, use_container_width=True)
            st.download_button(
                "⬇️ ranking.csv (full)",
                data=csv_text,
                file_name=f"{sel}_ranking.csv",
                mime="text/csv",
            )
        except Exception as e:
            st.warning(f"Ranking preview failed: {e}")

    # ---------- 3D VIEWER ----------
    st.markdown("---")
    st.subheader("🧬 3D Pose Viewer")
    ligand_titles = [L["title"] for L in master["per_ligand"]]
    sel_lig = st.selectbox("Ligand", ligand_titles, key="pose_ligand")
    ligand_data = next(L for L in master["per_ligand"] if L["title"] == sel_lig)
    boltz_data = (ligand_data.get("results") or {}).get("boltz") or {}

    view_mode = st.radio("Pose source",
                         ["Boltz-2", "Vina top", "GNINA top"],
                         horizontal=True)

    try:
        if view_mode == "Boltz-2":
            complex_pdb = boltz_data.get("complex_pdb")
            if complex_pdb and Path(complex_pdb).exists():
                display_3d_viewer(Path(complex_pdb).read_text())
            else:
                st.info("Boltz complex PDB not found")
        elif view_mode == "Vina top":
            p_pdb = boltz_data.get("protein_pdb")
            v_pdbqt = ((ligand_data.get("results") or {}).get("vina") or {}).get("output_pdbqt")
            if p_pdb and v_pdbqt and Path(v_pdbqt).exists():
                display_3d_viewer(Path(p_pdb).read_text(),
                                  ligand_text=Path(v_pdbqt).read_text())
            else:
                st.info("Vina output not found")
        elif view_mode == "GNINA top":
            p_pdb = boltz_data.get("protein_pdb")
            if p_pdb and Path(p_pdb).exists():
                display_3d_viewer(Path(p_pdb).read_text())
                g_sdf = ((ligand_data.get("results") or {}).get("gnina") or {}).get("output_sdf")
                if g_sdf:
                    st.caption(f"GNINA SDF: {g_sdf}")
            else:
                st.info("Protein PDB not found")
    except Exception as e:
        st.error(f"Viewer error: {e}")

    # ---------- PER-LIGAND DOWNLOADS ----------
    st.markdown("---")
    st.subheader(f"📥 Single-Ligand Downloads ({sel_lig})")
    dcol1, dcol2, dcol3, dcol4 = st.columns(4)

    boltz_complex = boltz_data.get("complex_pdb")
    if boltz_complex and Path(boltz_complex).exists():
        with dcol1:
            st.download_button(
                "🧬 Boltz complex (PDB)",
                data=Path(boltz_complex).read_bytes(),
                file_name=f"{sel_lig}_boltz_complex.pdb",
                mime="chemical/x-pdb",
                use_container_width=True,
            )

    boltz_lig_sdf = boltz_data.get("ligand_sdf")
    if boltz_lig_sdf and Path(boltz_lig_sdf).exists():
        with dcol2:
            st.download_button(
                "💊 Boltz ligand (SDF)",
                data=Path(boltz_lig_sdf).read_bytes(),
                file_name=f"{sel_lig}_boltz_pose.sdf",
                mime="chemical/x-mdl-sdfile",
                use_container_width=True,
            )

    vina_data = (ligand_data.get("results") or {}).get("vina") or {}
    vina_pdbqt = vina_data.get("output_pdbqt")
    if vina_pdbqt and Path(vina_pdbqt).exists():
        with dcol3:
            st.download_button(
                "🎯 Vina poses (PDBQT)",
                data=Path(vina_pdbqt).read_bytes(),
                file_name=f"{sel_lig}_vina_poses.pdbqt",
                mime="chemical/x-pdbqt",
                use_container_width=True,
            )

    gnina_data = (ligand_data.get("results") or {}).get("gnina") or {}
    gnina_sdf = gnina_data.get("output_sdf")
    if gnina_sdf and Path(gnina_sdf).exists():
        with dcol4:
            st.download_button(
                "🏆 GNINA poses (SDF)",
                data=Path(gnina_sdf).read_bytes(),
                file_name=f"{sel_lig}_gnina_poses.sdf",
                mime="chemical/x-mdl-sdfile",
                use_container_width=True,
            )

    st.markdown("---")
    with st.expander("Raw run JSON"):
        st.json(master)

    render_footer()


# =================================================================
# PAGE: ABOUT
# =================================================================
elif page == "ℹ️ About":
    render_header()
    st.title("About VS-Suite")
    st.markdown("""
    **VS-Suite** (Virtual Screening Suite) is an in-house automated docking pipeline
    developed by the **Centre for Advanced Computation and Theoretical Sciences (ACTS)**
    at SRMIST.

    ### Workflow
    1. **Input**: protein FASTA + ligands CSV (title, smiles)
    2. **Boltz-2** (AI co-folding): predicts protein-ligand complex + binding affinity
    3. **Auto-extract**: protein PDB, ligand SDF, binding-site box from Boltz output
    4. **Vina + GNINA**: classical & CNN-based docking refinement in same box
    5. **Consensus ranking**: cross-tool agreement for top hit selection
    6. **Bulk downloads**: top-10 (all poses) and top-20 (best pose each) ZIPs

    ### Tools (open-source)
    - **Boltz-2** — AI structure + affinity prediction
    - **AutoDock Vina** — classical empirical docking
    - **GNINA** — Vina + CNN scoring
    - **OpenBabel, RDKit, Meeko** — format conversion + ligand prep
    - **PDB2PQR, PROPKA** — pH-aware protonation
    - **Streamlit** — this GUI
    - **Biopython** — sequence + structure I/O

    ### Conda environment map
    | Env | Purpose |
    |-----|---------|
    | `autodock-main` | Orchestrator, GUI, RDKit, Biopython |
    | `boltz2` | Boltz-2 inference |
    | `autodock-prep` | OpenBabel, PDB2PQR, Meeko, fpocket |
    | (PATH) | Vina + GNINA binaries |

    ### Citations
    If you use VS-Suite results in publications, please cite:
    - Passaro et al., **Boltz-2** (2025)
    - Trott & Olson, **AutoDock Vina** (2010); Eberhardt et al. (2021)
    - McNutt et al., **GNINA 1.0** (2021)
    - O'Boyle et al., **OpenBabel** (2011)
    - Jurrus et al., **PDB2PQR / PROPKA** (2018)

    ---
    *Internal R&D tool. Developed at ACTS, SRMIST.*
    """)
    render_footer()
