"""Phase 1 smoke test — verifies utils + tool connectivity."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.utils.logger import setup_logger
from core.utils.config import load_config, save_config, merge_configs
from core.utils.paths import ProjectPaths
from core.utils.conda_runner import run_binary, run_in_conda_env, check_tool_available


def banner(msg):
    print("\n" + "=" * 60)
    print(f"  {msg}")
    print("=" * 60)


def test_logger():
    banner("Test 1: Logger")
    log = setup_logger(log_dir="logs", log_name="test_phase1", level="DEBUG")
    log.info("Logger OK")
    print("[PASS] Logger initialized")


def test_config():
    banner("Test 2: Config Loader")
    cfg = load_config("configs/default.yaml")
    assert "project" in cfg
    assert "tools" in cfg
    assert "docking" in cfg
    print(f"[PASS] Config loaded with {len(cfg)} top-level sections")
    print(f"       Sections: {list(cfg.keys())}")

    merged = merge_configs(cfg, {"project": {"name": "override_test"}})
    assert merged["project"]["name"] == "override_test"
    print("[PASS] Config merge works")


def test_paths():
    banner("Test 3: Project Paths")
    p = ProjectPaths.from_root("results/demo_phase1")
    assert p.inputs.exists()
    assert p.boltz.exists()
    assert p.vina.exists()
    assert p.gnina.exists()
    print(f"[PASS] Project paths created at {p.root}")
    print(f"       Subdirs: inputs, prep, boltz, vina, gnina, scoring, reports, logs")


def test_vina():
    banner("Test 4: Vina Connectivity")
    if not check_tool_available("vina", kind="binary"):
        print("[FAIL] vina not in PATH")
        return False
    result = run_binary("vina", ["--version"], timeout=30)
    if result.returncode == 0 or "Vina" in result.stdout or "Vina" in result.stderr:
        print(f"[PASS] Vina callable")
        print(f"       Output: {(result.stdout + result.stderr).strip().splitlines()[0]}")
        return True
    print(f"[FAIL] Vina returned code {result.returncode}")
    print(f"       stderr: {result.stderr}")
    return False


def test_gnina():
    banner("Test 5: GNINA Connectivity")
    if not check_tool_available("gnina", kind="binary"):
        print("[FAIL] gnina not in PATH")
        return False
    result = run_binary("gnina", ["--version"], timeout=30)
    if result.returncode == 0 or "gnina" in result.stdout.lower():
        print(f"[PASS] GNINA callable")
        first_line = (result.stdout + result.stderr).strip().splitlines()[0]
        print(f"       Output: {first_line}")
        return True
    print(f"[FAIL] GNINA returned code {result.returncode}")
    print(f"       stderr: {result.stderr}")
    return False


def test_boltz():
    banner("Test 6: Boltz-2 Connectivity (via conda env 'boltz2')")
    result = run_in_conda_env("boltz2", ["boltz", "--help"], timeout=60)
    if result.returncode == 0:
        print(f"[PASS] Boltz-2 callable in env 'boltz2'")
        first_line = result.stdout.strip().splitlines()[0] if result.stdout else "(no output)"
        print(f"       Output: {first_line[:80]}")
        return True
    print(f"[FAIL] Boltz returned code {result.returncode}")
    print(f"       stderr: {result.stderr[:300]}")
    return False


if __name__ == "__main__":
    test_logger()
    test_config()
    test_paths()
    v = test_vina()
    g = test_gnina()
    b = test_boltz()

    banner("PHASE 1 SUMMARY")
    print(f"  Vina:    {'OK' if v else 'FAIL'}")
    print(f"  GNINA:   {'OK' if g else 'FAIL'}")
    print(f"  Boltz-2: {'OK' if b else 'FAIL'}")
    if v and g and b:
        print("\n  >>> Phase 1 COMPLETE. Ready for Phase 2 tomorrow. <<<")
    else:
        print("\n  >>> Some tools failed. Paste output for fix. <<<")
